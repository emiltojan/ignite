import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'filtername',
    pure: false
})
export class FilterByName implements PipeTransform {
    transform(items: any[], name): any {
           return name  ? items.filter(item => item.associateName.indexOf(name) !== -1): items;
        
    }
}


@Pipe({
    name: 'filterid',
    pure: false
})
export class FilterById implements PipeTransform {
    transform(items: any[], name): any {
           return name  ? items.filter(item => item.taAssociateId.indexOf(name) !== -1): items;
        
    }
}


@Pipe({
    name: 'filterscc',
    pure: false
})
export class FilterBySCC implements PipeTransform {
    transform(items: any[], name): any {
            return name  ? items.filter(item => item.supplyChainCd.toLowerCase().startsWith(name.toLowerCase())): items;
           
        
    }
}

@Pipe({
    name: 'filterops',
    pure: false
})
export class FilterByOPs implements PipeTransform {
    transform(items: any[], name): any {
           return name  ? items.filter(item => item.operationalAreaDesc.indexOf(name) !== -1): items;
        
    }
}

@Pipe({
    name: 'filterjob',
    pure: false
})
export class FilterByJob implements PipeTransform {
    transform(items: any[], name): any {
           return name  ? items.filter(item => item.jobFunctionDesc.indexOf(name) !== -1): items;
        
    }
}

@Pipe({
    name: 'filterdfltshift',
    pure: false
})
export class FilterByDfltShift implements PipeTransform {
    transform(items: any[], name): any {
           return name  ? items.filter(item => item.dfltShiftNbr.indexOf(name) !== -1): items;
        
    }
}

@Pipe({
    name: 'filterdfltfacility',
    pure: false
})
export class FilterByDfltFacility implements PipeTransform {
    transform(items: any[], name): any {
           return name  ? items.filter(item => item.dfltFacilityAreaCode.indexOf(name) !== -1): items;
        
    }
}

@Pipe({
    name: 'filteropsareadesc',
    pure: false
})
export class FilterByOpsAreaDesc implements PipeTransform {
    transform(items: any[], name): any {
           return name  ? items.filter(item => item.opsAreaDesc.indexOf(name) !== -1): items;
        
    }
}

@Pipe({
    name: 'filterassocname',
    pure: false
})
export class FilterByAssocName implements PipeTransform {
    transform(items: any[], name): any {
           return name  ? items.filter(item => item.assocName.indexOf(name) !== -1): items;
        
    }
}

@Pipe({
    name: 'filterfacility',
    pure: false
})
export class FilterByFacility implements PipeTransform {
    transform(items: any[], name): any {
           return name  ? items.filter(item => item.facilityId.indexOf(name) !== -1): items;
        
    }
}