import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { Modal } from 'ngx-modialog/plugins/bootstrap';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AssignShiftComponent } from './assign-shift.component';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import {Http,HttpModule} from '@angular/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";
import { AppComponent } from '../../app.component';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { TimesheetService } from './../../services/timesheet.service';
import { AssignShiftService } from '../../services/assign-shift.service';
import { AppCommonServices } from './../../services/app-common.services';
import {GetExceptionsService} from './../../services/exception.service';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
export function HttpLoaderFactory(httpClient: HttpClient) {
 //return new TranslateHttpLoader(httpClient, "assets/i18n/", ".txt"); // Local
   return new TranslateHttpLoader(httpClient, "/tpr/assets/i18n/", ".txt"); // Production
}


describe('AssignShiftComponent', () => {
  let component: AssignShiftComponent;
  let fixture: ComponentFixture<AssignShiftComponent>;
  let modal;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignShiftComponent ],
      schemas: [NO_ERRORS_SCHEMA],
        imports:[ 
       BrowserModule,
       FormsModule,
       HttpModule,
       HttpClientModule, 
       HttpClientTestingModule, 
       TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
       }}),
      RouterTestingModule],
      providers:[TimesheetService,{ provide: Modal, useValue: modal }, AssignShiftService, AppComponent, NavbarComponent,AppCommonServices,GetExceptionsService]
    })
    .compileComponents();
     modal = { openModal: jasmine.createSpy('openModal') }
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignShiftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call showModalBox method ',function () {
    spyOn(component,'showModalBox');
    component.showModalBox(testData().data);
expect(component.showModalBox).toHaveBeenCalledWith(testData().data);
  });

it('should call onShiftChange method ',function () {
    spyOn(component,'onShiftChange');
    component.onShiftChange(testData().shiftNbr);
expect(component.onShiftChange).toHaveBeenCalledWith(testData().shiftNbr);
  });

//   it('should call onshiftSelect method ',function () {
//     spyOn(component,'onshiftSelect');
//     component.onshiftSelect(testData().shiftNbr);
// expect(component.onshiftSelect).toHaveBeenCalledWith(testData().shiftNbr);
//   });

//    it('should call updateShift method ',function () {
//     spyOn(component,'updateShift');
//     component.updateShift(testData().shiftNbr);
// expect(component.updateShift).toHaveBeenCalledWith(testData().pay);
//   });

  it('should call addNewShift method ',function () {
    spyOn(component,'addNewShift');
    component.addNewShift();
expect(component.addNewShift).toHaveBeenCalled();
  });

});

function testData(){
    return {
        data : 'dummydata',
        shiftNbr:2,
        pay :{
        facilityId:1,

        }
    }
}
