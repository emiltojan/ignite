import { Component, OnInit, ViewChild , Output, EventEmitter,Input} from '@angular/core';
import { AssignShiftService } from './../../services/assign-shift.service';
import { ShiftSetupService } from './../../services/shift-setup.service';
import { NgForm } from '@angular/forms';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { Overlay } from 'ngx-modialog';
import { Modal } from 'ngx-modialog/plugins/bootstrap';

import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'app-assign-shift',
  templateUrl: './assign-shift.component.html',
  styleUrls: ['./assign-shift.component.css','./bootstrap-3.3.5-dist/css/bootstrap.css'],
  providers: [AssignShiftService, ShiftSetupService]
})

export class AssignShiftComponent implements OnInit {
  Assignshift: any[] = [];
  ShiftList: any[] = [];
  FacilityList: any[] = [];
  AssociateDetails: any;
  public showAddNewShift: boolean = false;
  public enableShift: boolean = true;
  public newShift: number = 0;
  endTime: any;
  startTime: any;
  shiftEndTimeFormat: any;
  shiftStartTimeFormat: any;
  shiftNbr: any;
  shiftDate: any;
@Input() dcShift;
  @Input() facilityLst;
  @Output() userUpdated = new EventEmitter();

  constructor(public service: AssignShiftService,
    public shiftService: ShiftSetupService,
    public router: Router,
    public modal: Modal,
    private translate: TranslateService) {
    translate.addLangs(["en", "ch"]);} 

  private showModal;

  @ViewChild('shiftData') public shiftData: NgForm;

  ngOnInit() {
    // this.service.getShiftsList()
    //   .subscribe((ShiftDetails:any) => {
    //     if(ShiftDetails!==null)
    //     {
    //       if(ShiftDetails!==undefined &&ShiftDetails.dcShift!==undefined){
    //           this.ShiftList = ShiftDetails.dcShift;
    //       }
    //     }
        
    //   },(err)=>{
    //     console.error('failed to retrieve shift details');
    //   });
    // this.shiftService.getFacility()
    //   .subscribe((FacilityData:any) => {
    //     if(FacilityData!==null)
    //     {
    //       if(FacilityData!==undefined&&FacilityData.FacilityTO!==undefined)
    //       {
    //         this.FacilityList = FacilityData.FacilityTO;
    //       }
    //     }
        
    //   },(err)=>{
    //     console.error('failed to retrieve associate data');
    //   });
   this.shiftDate = new Date();    
  }

  showModalBox(data: any) {
    this.showModal = true;
    this.AssociateDetails = data;
     var date = new Date();
    let str = date.getDate();
    console.log(str.toString().length);
    if (str.toString().length == 1) {
      this.shiftDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-0' + date.getDate();
    } else {
      this.shiftDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    }

  }

  closeModal(shiftData: NgForm) {
    this.enableShift = true;
    this.showModal = false;
    shiftData.resetForm();
  }

  onShiftChange(event: any) {
    this.ShiftList.filter(function (list) {
      if (list.shiftNbr == event) {
        console.log(moment(list.startTime).format("HH:mm"));
      }
    });
  }

  onshiftSelect(shift,list) {
console.log(list);
    let selectedShift = list.find(shiftData => {
      return shiftData.shiftCode == shift;
    });
    console.log(selectedShift);
    this.startTime = selectedShift.shiftStartTs;
    this.endTime = selectedShift.shiftEndTs;
    if (this.startTime > "13") {     
      this.shiftStartTimeFormat = "PM";
    } else {
      this.shiftStartTimeFormat = "AM";
    }

if (this.endTime > "13") {
      this.shiftEndTimeFormat = "PM";
    } else {
      this.shiftEndTimeFormat = "AM";
    }
  }

  updateShift(shiftData: NgForm) {
    console.log(shiftData.value);      
    console.log(this.AssociateDetails);

    var pay: any = { associateDetails: [] };
    pay = shiftData.value;
    if(pay.shiftStartTime!==undefined && pay.shiftEndTime!==undefined)
    {
        if (pay.shiftStartTime.split(':')[0] >=24 || pay.shiftEndTime.split(':')[0] >=60  ) {
      this.modal.alert().title('').body('Invalid Time selected').open();
    } else {
    for (let j = 0; j < this.AssociateDetails.length; j++) {
      this.AssociateDetails[j].dfltFacilityAreaCode = pay.facilityId;
      this.AssociateDetails[j].obsoleteInd = "N";
    }

    pay.associateDetails = this.AssociateDetails;
    if (this.enableShift) {
      pay.shiftCreateIndicator = "false",
        pay.shiftUpdateIndicator = "true"
    } else {
      pay.shiftCreateIndicator = "true",
        pay.shiftUpdateIndicator = "false"
    }

    this.service.assignShift(pay)
      .subscribe((AssociateData) => {
        if (this.enableShift) {
          this.modal.alert().title('Message').body('Shift assignment successful').open();
          setTimeout(() => {
          }, 2000);
          console.log(AssociateData);
        }
        else {
          this.modal.alert().title('Message').body('Shift added successfull').open();
          setTimeout(() => {
          }, 2000);
        }
        console.log(AssociateData);
        this.closeModal(shiftData);
        this.userUpdated.emit('test');
      },(err)=>{
        this.modal.alert().title('Error').body('Failed to assign Shift').open();
        setTimeout(() => {
        }, 2000);
        console.error('failed to add new associate data');
      });
    }
    }
 
  }
  // addNewShift(value) {
  //   var tempObj = {
  //     shiftNbr: value
  //   };
  //   this.ShiftList.push(tempObj);
  // }


  addNewShift() {
    this.enableShift = false;
  }

}
