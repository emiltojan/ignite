import { Component, OnInit, ViewChild, Output,Input, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import {FormControl,Validators} from '@angular/forms';
import { AddAssociateService } from './../../services/add-associate.service';
import { AssignShiftService } from './../../services/assign-shift.service';
import { ShiftSetupService } from './../../services/shift-setup.service';
import { Overlay } from 'ngx-modialog';
import { Modal } from 'ngx-modialog/plugins/bootstrap';

import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'app-add-associate',
  templateUrl: './add-associate.component.html',
  styleUrls: ['./add-associate.component.css'],
  providers: [AddAssociateService, AssignShiftService, ShiftSetupService]
})
export class AddAssociateComponent implements OnInit {
  AssociateDetails: any[] = [];
  ShiftList: any[] = [];
  departList:any[]=[];
  FacilityList: any[] = [];
  public exportOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: false,
    headers: (['Associate Id', 'Name', 'Shift', 'SCC', 'Time']),
    showTitle: false,
    useBom: true
  };
  uploadAssociates: any;
  uploadTime: any;
  EffDate: any;
  dateVal='';
  dateMonth:any;
  dateDate :any;
  assocTypeList :any[]=[];
  assocTypeCode :any;
  shiftEffectiveDate:any;
  shiftDate :any;
  clockTypeList:any=["1","2","3","4"]
  @Input() dcShift;
  @Input() facilityLst;
  @Output() userUpdated = new EventEmitter();
  constructor(public addAssociateService: AddAssociateService,
    public assignShitService: AssignShiftService,
    public shiftService: ShiftSetupService,
    public modal: Modal,
    private translate: TranslateService) {
    translate.addLangs(["en", "ch"]);
  }

  private hideModal: boolean = true;
  private formSubmitted: boolean = false;
  public isHideUpload: boolean;
  public fromTimeSheet: boolean;
  ngOnInit() {

    // this.assignShitService.getShiftsList()
    //   .subscribe((ShiftDetails:any) => {
    //     if(ShiftDetails!==null)
    //     {
    //       if(ShiftDetails!==undefined &&ShiftDetails.dcShift!==undefined)
    //       {
    //         this.ShiftList = ShiftDetails.dcShift;
    //       }
            
    //     } 
    //   },(err)=>{
    //     console.error('failed to retrieve shift details');
    //   });
    this.assignShitService.getAssocTypeCode()
    .subscribe((assocTypeLists:any) => {
      if (assocTypeLists !==null) {
        this.assocTypeList=assocTypeLists.AssociateTypeTO;
        console.log('this.assocTypeList ', this.assocTypeList);
      }
    })
   // this.assocTypeList=['Full Time','Regular','Temp Staff','3 PL','Supervisor','Manager','Others'];

       this.assignShitService.getDepartment()
      .subscribe((departLists:any) => {
        if(departLists!==null)
        {
          this.departList=departLists.DcDepartmentTO;  
          console.log('this.departList',this.departList); 
        } 
      },(err)=>{
        console.error('failed to retrieve shift details');
      });
      

    // this.shiftService.getFacility()
    //   .subscribe((FacilityData:any) => {
    //     if(FacilityData!==null)
    //     {
    //       this.FacilityList = FacilityData.FacilityTO;
    //     }
    //   },(err)=>{
    //     console.error('failed to retrieve associate data');
    //   });
     
    var date = new Date();
    let str = date.getDate();
    console.log(str.toString().length);
    if (str.toString().length == 1) {
      this.EffDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-0' + date.getDate();
    } else {
      this.EffDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    }
    this.shiftDate=new Date();
    this.shiftEffectiveDate = new Date();  
  }

  @ViewChild('newAssociate') private newAssociate: NgForm;
  @ViewChild('fileUpload')fileUploadDiv: any;
  showModalBox(value: boolean, timeSheet: boolean) {
    this.hideModal = false;
    this.isHideUpload = value;
    this.fromTimeSheet = timeSheet;
  }

  closeModal(newAssociate: NgForm) {
    this.hideModal = true;
    newAssociate.reset();
    newAssociate.resetForm();
  }
  onDateChange(event){
     var yesdyDate = new Date(event.targetElement.value);
     console.log('yesdyDate '+yesdyDate);
      var date1=yesdyDate.getFullYear()+'-'+(yesdyDate.getMonth()+1)+'-'+yesdyDate.getDate();
      this. dateVal=date1;
      
      
    }

  addNewAssociate(newAssociate: NgForm) {
    this.formSubmitted = true;
    // this.fileUploadDiv.nativeElement.value = ""
    if (!newAssociate.invalid) {
      var associateDetails = newAssociate.value;
      associateDetails.obsoleteInd = "N";
     // console.log("this.dateval", this.dateVal);
      // if (this.dateVal.split('-')[1].length ===1) {
      //    this.dateMonth = '0'+this.dateVal.split('-')[1];
      // } else {
      //   this.dateMonth = this.dateVal.split('-')[1];
      // }
      // if (this.dateVal.split('-')[2].length ===1) {
      //    this.dateDate = '0'+this.dateVal.split('-')[2];
      // } else {
      //   this.dateDate = this.dateVal.split('-')[2];
      // }
      // this.dateVal=this. dateVal.split('-')[0]+'-'+ this.dateMonth+'-'+this.dateDate;
     // associateDetails.shiftEffectiveDate = this.dateVal;
     // associateDetails.assocTypeCode = this.assocTypeCode;
      var associateData = {
        associateDetails: [associateDetails]
      }
      console.log(associateData);
      if (this.fromTimeSheet) {
        if (this.isHideUpload) {
          
          var timeData = [
            {
             "clockTypeCode":associateDetails.clockTypeCode,
             "associateId": associateDetails.associateId,
              "clockTime": associateDetails.shiftStartTime,
              "clockDate": associateDetails.shiftDate,
              "supplyChainCd":associateDetails.supplyChainCd,
              "shiftnbr":associateDetails.shiftCode
            }
          ];

          console.log('timeData', timeData);
          this.addTime(timeData, newAssociate);
        } else {
          this.addTime(this.uploadTime, newAssociate);
        }
      } else {
        if (this.isHideUpload) {
          if (associateDetails.supplyChainCd) {
            //service logic to validate ssc
            this.addAssociateService.validateSCC(associateDetails.supplyChainCd)
              .subscribe((response:any) => {
               // console.log(response.status);
                if (response!==null) {
                  console.log("Response " +JSON.stringify(response));
                  //service logic serviceName(newAssociate.value)
                  newAssociate.enabled;
                  this.add(associateData, newAssociate);
                }
                else {
                  this.modal.alert().title('Error').body('Invalid Job Code').open();
                  setTimeout(() => {
                  }, 2000);
                //  newAssociate.resetForm();
                }
              },(err)=>{

                this.modal.alert().title('Error').body('Service temporarily unavailable . Please try again ').open();
                setTimeout(() => {
                }, 2000);
               
              });
              
          }
        } else {
          this.add(this.uploadAssociates, newAssociate);
        }
      }
    }
  }

  resetAddNewAssociateForm() {
    this.hideModal = true;
    this.formSubmitted = false;
  }

  add(associateData, newAssociate) {
    this.addAssociateService.addAssociate(associateData)
      .subscribe((AssociateData) => {
        this.modal.alert().title('Message').body('Associate added successfully').open();
        setTimeout(() => {
        }, 2000);
       
        this.resetAddNewAssociateForm();
        this.userUpdated.emit('Added');
        newAssociate.resetForm();
      },(err)=>{
        this.modal.alert().title('Error').body('Failed to add new associate').open();
        setTimeout(() => {
        }, 2000);
       // newAssociate.resetForm();
        console.error('failed to add new associate');
      })
      
  }

changeAssocType ( assocType) {
  this.assocTypeCode = assocType.value;
  //console.log('Assoc Type Value ' + assocType.value);
}
  addTime(data, newAssociate) {
    this.addAssociateService.addTimeAttendance(data)
      .subscribe((res) => {
        this.modal.alert().title('Message').body('Associate added successfully').open();
        setTimeout(() => {
        }, 2000);
        console.log(res);
        this.resetAddNewAssociateForm();
        this.userUpdated.emit('Added');
        newAssociate.resetForm();
        newAssociate.reset();
      },(err)=>{
        this.modal.alert().title('Error').body('Failed to add new associate').open();
        setTimeout(() => {
        }, 2000);
        console.error('failed to add new associate');
      })
      
  }
  //File upload

  handleFileSelect(evt) {
    var files = evt.target.files; // FileList object
    var file = files[0];
    var reader = new FileReader();
    reader.readAsText(file);
    reader.onload = (data) => {
      var csv = reader.result; // Content of CSV file
      this.extractData(csv); //Here you can call the above function.
    }
  }

  exportData() {
    var exportData: any[] =[];
    for (let j = 0; j < this.AssociateDetails.length; j++) {   
      exportData[j] = {
       // "taAssociateId" : this.AssociateDetails[j].taAssociateId,
      "associateId" : this.AssociateDetails[j].taAssociateId,
      "associateName" :  this.AssociateDetails[j].associateName,
      "shiftnbr" : this.AssociateDetails[j].shiftnbr,
      "supplyChainCd" : this.AssociateDetails[j].supplyChainCd,
      "totalClockedIntime"  : this.AssociateDetails[j].totalClockedIntime                             
      };
    } 
    console.log('exported data', exportData);
    new Angular2Csv(exportData, 'TimeSheetData', this.exportOptions);
  }

  extractData(data) { // Input csv data to the function

    let csvData = data;
    let allTextLines = csvData.split(/\r\n|\n/);
    let headers = allTextLines[0].split(',');
    let lines = [];

    for (let i = 0; i < allTextLines.length; i++) {
      // split content based on comma
      let data = allTextLines[i].split(',');
      if (data.length == headers.length) {
        let tarr = [];
        for (let j = 0; j < headers.length; j++) {
          tarr.push(data[j]);
        }
        lines.push(tarr);
      }
    }
    
//The data in the form of 2 dimensional array.    

    this.uploadAssociates = {};
    this.uploadTime = [];

    if (this.fromTimeSheet) {
      var TimeDetails: any[] = [];
      for (let j = 0; j < lines.length; j++) {
        var uploadedInTime: any;
        var uploadedOutTime: any;
        var uploadedBeforeMealTime: any;
        var uploadedAfterMealTime: any;
        //csv format AssociateId0,type1,date2,time3,shift4,scc5
        uploadedInTime = {
         
         "associateId": lines[j][0].replace(/"/g, ""),
         "clockTypeCode":lines[j][1].replace(/"/g, ""),
          "clockTime": lines[j][3].replace(/"/g, ""),
          "shiftnbr": lines[j][4].replace(/"/g, ""),
          "clockDate": lines[j][2].replace(/"/g, ""),
          "supplyChainCd": lines[j][5].replace(/"/g, "")
        };
        
        
      
       TimeDetails.push(uploadedInTime);
      }
      this.uploadTime =  TimeDetails ;
     

    } else {
      var associateDetails: any[] = [];

      //CSV format[ Associate Id0, First Name1, Last Name2, Gls Userid3, Department Number4, Associate Type Code5, SCC6, Facility Id7, Shift Code8, Shift Effective Date9*, Supervisor Id10 ]
      for (let j = 0; j < lines.length; j++) {
        var uploadedData: any;
        uploadedData = {
          "associateId": lines[j][0].replace(/"/g, ""),
          "firstName": lines[j][1].replace(/"/g, ""),
          "lastName": lines[j][2].replace(/"/g, ""),
           "glsUserid": lines[j][3].replace(/"/g, ""),
          "deptNbr": lines[j][4].replace(/"/g, ""),
          "assocTypeCode": lines[j][5].replace(/"/g, ""),
          "supplyChainCd": lines[j][6].replace(/"/g, ""),
          "facilityAreaCode": lines[j][7].replace(/"/g, ""),
          "shiftCode": lines[j][8].replace(/"/g, ""),
          "shiftEffectiveDate": lines[j][9].replace(/"/g, ""),
          "supervisorUserId": lines[j][10].replace(/"/g, ""),
          "obsoleteInd": "N",
        };
        associateDetails.push(uploadedData);
      }
      this.uploadAssociates = { associateDetails };
      console.log('Associate details', this.uploadAssociates);
    }

  }

}
