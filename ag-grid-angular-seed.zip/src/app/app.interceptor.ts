import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
//import { LoginService } from './services/login.service';
@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor() {}
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
      console.log('<--intercept-->');
      console.log('lang-code',sessionStorage.getItem('loggedInLanguage'));
      console.log('lang-code',sessionStorage.getItem('loggedInUserId'));
      let usrLang='',countryCode='';
if(sessionStorage.getItem('loggedInLanguage')==='ch')
      {
          usrLang='107';
      }else if(sessionStorage.getItem('loggedInLanguage')==='en')
      {
          usrLang='101';
      }
    request = request.clone({
       setHeaders: {
        'WMT-USER-ID':sessionStorage.getItem('loggedInUserId'),
        'LANG-CODE':usrLang,
        'COUNTRY-CODE' :sessionStorage.getItem('loggedinDomain'),
        'DC-NBR':sessionStorage.getItem('loggedinDC'),
      // 'WMT-Security-ID': sessionStorage.getItem('securityId'),
        'WMT-BusinessUnitID': sessionStorage.getItem('loggedinDC'),
       // 'WMT-Token': sessionStorage.getItem('token'),
       //'Access-Control-Allow-Origin':'*'
      }
    });
    console.log(request);
    return next.handle(request);
  }//
}
