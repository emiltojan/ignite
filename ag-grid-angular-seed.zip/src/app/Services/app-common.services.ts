import {Injectable} from '@angular/core';


@Injectable()
export class AppCommonServices {
      constructor() {
    console.clear();
    console.log('AppCommonServices created')
  }
    getLanguageCode(){
      let code='';
      if(sessionStorage.getItem('loggedInLanguage')==='en')
        {
            code='101';
        }else if(sessionStorage.getItem('loggedInLanguage')==='ch')
        {
            code='107';
        }
        return code;
    }
}