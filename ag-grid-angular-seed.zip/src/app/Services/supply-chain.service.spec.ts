import { TestBed, async, inject } from '@angular/core/testing';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod,HttpModule} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule,HttpTestingController} from '@angular/common/http/testing';
import 'rxjs/add/operator/toPromise';
import { AppCommonServices } from './app-common.services';
import { SupplyChainService } from './supply-chain.service';

describe('SupplyChainService (Mocked)', () => {
  const mockResponse = {
      color: 'blue'
    };

  let subject: SupplyChainService = null;
  let backend: MockBackend = null;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        SupplyChainService,
        AppCommonServices,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule,HttpClientModule,HttpClientTestingModule
      ]
    });
  });
 
  beforeEach(inject([SupplyChainService, MockBackend], (getException: SupplyChainService, mockBackend: MockBackend) => {
    subject = getException;
    backend = mockBackend;
  }));

  it('should construct SupplyChainService service', async(inject(
    [SupplyChainService, MockBackend], (service, mockBackend) => {

    expect(service).toBeDefined();
  })));

it(`should expect a GET /foo/bar`, async(inject([HttpClient, HttpTestingController],
    (http: HttpClient, backend: HttpTestingController) => {
      http.get(`http://us32846s4000d0b.s32846.us:9887/tpr/us/7490/supplychain?langCode=101`).subscribe();

      backend.expectOne({
        url: `http://us32846s4000d0b.s32846.us:9887/tpr/us/7490/supplychain?langCode=101`,
        method: 'GET'
      });
  })));

    it('should call saveSupplyChainCode service method', async(inject([SupplyChainService, MockBackend], (dashBoard: SupplyChainService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify('') })));
      });

      subject
      .saveSupplyChainCode(SCData())
      .subscribe((response) => {
        expect(subject.saveSupplyChainCode(SCData())).toEqual({success:true});
      });
    })));
    
     it('should call saveSupplyChainGoal service method', async(inject([SupplyChainService, MockBackend], (dashBoard: SupplyChainService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify('') })));
      });

      subject
      .saveSupplyChainGoal(SCData())
      .subscribe((response) => {
        expect(subject.saveSupplyChainGoal(SCData())).toEqual({success:true});
      });
    })));


});

function SCData(){
  return {
  "activeInd": "Y",
  "facilityId": "1",
  "jobFunctionCd": "1",
  "jobFunctionDesc": "Unloading/Processing",
  "metricTypeDesc": "Pallets",
  "operationalAreaCd": "1",
  "operationalAreaDesc": "RECEIVING",
  "prodMetricCode": "1",
  "productivityGoal": "120",
  "supplyChainCd": "001082001",
  "workAreaCd": "82",
  "workAreaDesc": "Store Fixtures",
  "checkBoxValue": true,
  "uomCode": "1"
}
}
