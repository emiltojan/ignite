import { TestBed, async, inject } from '@angular/core/testing';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod,HttpModule} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule,HttpTestingController} from '@angular/common/http/testing';
import 'rxjs/add/operator/toPromise';
import { AppCommonServices } from './app-common.services';
import { ShiftSetupService } from './shift-setup.service';

describe('ShiftSetupService (Mocked)', () => {
  const mockResponse = {
      color: 'blue'
    };

  let subject: ShiftSetupService = null;
  let backend: MockBackend = null;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ShiftSetupService,
        AppCommonServices,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule,HttpClientModule,HttpClientTestingModule
      ]
    });
  });
 
  beforeEach(inject([ShiftSetupService, MockBackend], (getException: ShiftSetupService, mockBackend: MockBackend) => {
    subject = getException;
    backend = mockBackend;
  }));

  it('should construct ShiftSetupService service', async(inject(
    [ShiftSetupService, MockBackend], (service, mockBackend) => {

    expect(service).toBeDefined();
  })));

it(`should expect a GET /foo/bar`, async(inject([HttpClient, HttpTestingController],
    (http: HttpClient, backend: HttpTestingController) => {
      http.get(`http://us32846s4000d0b.s32846.us:9887/tpr/us/7490/supplychain?langCode=101`).subscribe();

      backend.expectOne({
        url: `http://us32846s4000d0b.s32846.us:9887/tpr/us/7490/supplychain?langCode=101`,
        method: 'GET'
      });
  })));

    it('should call getAssociate service method', async(inject([ShiftSetupService, MockBackend], (dashBoard: ShiftSetupService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify('') })));
      });

      subject
      .getAssociate()
      .subscribe((response) => {
        expect(subject.getAssociate()).toEqual({ success: true });
      });
    })));
    
     it('should call getFacility service method', async(inject([ShiftSetupService, MockBackend], (dashBoard: ShiftSetupService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify('') })));
      });

      subject
      .getFacility()
      .subscribe((response) => {
        expect(subject.getFacility()).toEqual({success:true});
      });
    })));


});
