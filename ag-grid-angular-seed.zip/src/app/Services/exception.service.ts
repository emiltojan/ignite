import { Injectable } from '@angular/core';
//import { Component } from '@angular/core';
import { Http } from '@angular/http';
import {HttpClient} from '@angular/common/http';
import 'rxjs/add/operator/toPromise';

@Injectable()

export class GetExceptionsService {
 result: any;
  

 constructor(private http: Http) { }

    getExceptions(): Promise<any> {

           // return this.http.get('http://us32846s4000d0b.s32846.us:9887/tpr/us/7490/dashboard/associates/exceptions')
            return this.http.get('http://10.117.170.249:8080/tpr-web/dashboard/associates/exceptions')
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
    }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); 
        return Promise.reject(error.message || error);
    }

   

    
}
