import { TestBed, async, inject } from '@angular/core/testing';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod,HttpModule} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule,HttpTestingController} from '@angular/common/http/testing';
import { GetExceptionsService } from './exception.service';

describe('GetExceptionsService (Mocked)', () => {
  const mockResponse = {
      color: 'blue'
    };

  let subject: GetExceptionsService = null;
  let backend: MockBackend = null;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        GetExceptionsService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule,HttpClientModule,HttpClientTestingModule
      ]
    });
  });
 
  beforeEach(inject([GetExceptionsService, MockBackend], (getException: GetExceptionsService, mockBackend: MockBackend) => {
    subject = getException;
    backend = mockBackend;
  }));

  it('should construct GetExceptionsService service', async(inject(
    [GetExceptionsService, MockBackend], (service, mockBackend) => {

    expect(service).toBeDefined();
  })));


    it('should call GetExceptionsService service method', async(inject([GetExceptionsService, MockBackend], (dashBoard: GetExceptionsService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify('') })));
      });

      subject
      .getExceptions()
      .then((response) => {
        expect(subject.getExceptions()).toBeTruthy();
      });
    })));


});


// function testData() {

//  return { 
//  data :{
//    supplyChainCd :'1234',
//    shiftNbr : 2,
//    prodDate : '02/20/2018'
//  }
//  };
