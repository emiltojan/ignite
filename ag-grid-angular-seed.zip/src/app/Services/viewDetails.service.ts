import { Injectable } from '@angular/core';
//import { Component } from '@angular/core';
import { Http } from '@angular/http';
import {HttpClient} from '@angular/common/http';
import 'rxjs/add/operator/toPromise';

@Injectable()

export class ViewDetailsService {
 result: any;
  


    constructor(private http: Http) { }

    ViewDetails(data): Promise<any> {
 
            //return this.http.post('http://us32846s4000d0b.s32846.us:9887/tpr/us/7490/dashboard/jobcode/performance',data)
            return this.http.post('http://10.117.170.249:8080/tpr-web/dashboard/jobcode/performance',data)
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
    }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); 
        return Promise.reject(error.message || error);
    }

   

    
}
