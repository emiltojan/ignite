import { Component, OnInit, ViewChild } from '@angular/core';
import { LoginService } from '../../services/login.service';
import { Router } from '@angular/router';
import { MatSelectChange } from '@angular/material';
import { Modal } from 'ngx-modialog/plugins/bootstrap';
import {Http, Headers, RequestOptions} from '@angular/http';
import {FormControl} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [LoginService]
})
export class LoginComponent implements OnInit {
  userid: string;
  password: string;
  userName: string;
  selectedLanguage: string;
  selectedDomain: string;
  languages: [{ label: string, value: string }];
  domains: [{ label: string, value: string }];
  facilitys :[{label : string , value :string}];
  selectedDC :string;
  selectedLang : any = new FormControl('en');
  constructor(private loginSvc: LoginService,
              private router: Router, 
              http: Http,
              public modal: Modal) {
                
    if (localStorage.getItem('loggedInUser')) {
					this.router.navigate(['/supplychain']);
				}


   this.populateDomain();
   
  }


  ngOnInit() {
  }

   populateDCs() {
     if (this.selectedDomain === 'CN') {
     this.languages = [{ label: '', value: '' }];
    this.languages.push({ label: 'English', value: 'en' });
    this.languages.push({ label: 'Chinese', value: 'ch' });
     this.facilitys = [{ label: '', value: '' }];
    // this.facilitys.push({ label: '7428', value: '7428' });
    // this.facilitys.push({ label: '7429', value: '7429' });
    // this.facilitys.push({ label: '7433', value: '7433' });
    this.facilitys.push({ label: '7484', value: '7484' });
    // this.facilitys.push({ label: '7495', value: '7495' });
    // this.facilitys.push({ label: '7496', value: '7496' });
     } else if (this.selectedDomain === 'MX') {
      //  this.selectedLang=new FormControl('English');
       this.languages = [{ label: '', value: '' }];
    this.languages.push({ label: 'English', value: 'en' });
    this.languages.push({ label: 'Spanish', value: 'sp' });
    this.facilitys = [{ label: '', value: '' }];
      //  this.facilitys.push({ label: '6388', value: '6388' });
      //  this.facilitys.push({ label: '7453', value: '7453' });
      //  this.facilitys.push({ label: '7454', value: '7454' });
      //  this.facilitys.push({ label: '7457', value: '7457' });
      //  this.facilitys.push({ label: '7458', value: '7458' });
      //  this.facilitys.push({ label: '7459', value: '7459' });
      //  this.facilitys.push({ label: '7460', value: '7460' });
      //  this.facilitys.push({ label: '7461', value: '7461' });
      //  this.facilitys.push({ label: '7464', value: '7464' });
      //  this.facilitys.push({ label: '7466', value: '7466' });
      //  this.facilitys.push({ label: '7468', value: '7468' });
      //  this.facilitys.push({ label: '7471', value: '7471' });
      //  this.facilitys.push({ label: '7472', value: '7472' });
      //  this.facilitys.push({ label: '7482', value: '7482' });
      //  this.facilitys.push({ label: '7487', value: '7487' });
      //  this.facilitys.push({ label: '7490', value: '7490' });
      //  this.facilitys.push({ label: '7491', value: '7491' });
      //  this.facilitys.push({ label: '7492', value: '7492' });
       this.facilitys.push({ label: '7494', value: '7494' });
      //  this.facilitys.push({ label: '7495', value: '7495' });
      //  this.facilitys.push({ label: '7498', value: '7498' });
      //  this.facilitys.push({ label: '7499', value: '7499' });
     }
   }

  populateLanguage() {
    this.languages = [{ label: '', value: '' }];
    this.languages.push({ label: 'English', value: 'en' });
    this.languages.push({ label: 'Chinese', value: 'ch' });
  }

  populateDomain() {
    this.domains = [{ label: '', value: '' }];
    this.domains.push({ label: 'Mexico', value: 'MX' });
    this.domains.push({ label: 'China', value: 'CN' });
  }

  authenticate() {
console.log('authenticate');
    this.getIsSupervisior();
       // uncomment this to remove AU Authentication and deploy
       console.log('this.selectedLang',this.selectedLang.value);
       sessionStorage.setItem('loggedInUser', this.userName);
       sessionStorage.setItem('loggedInUserId', this.userid);
       sessionStorage.setItem('loggedInLanguage', this.selectedLang.value);
       sessionStorage.setItem('loggedinDC',this.selectedDC);
       sessionStorage.setItem('loggedinDomain',this.selectedDomain);
        this.loginSvc.getUserDetails.userName=this.userName;
        this.loginSvc.getUserDetails.userLang=this.selectedLang.value;
        this.loginSvc.getUserDetails.DC=this.selectedDC;
       // let link = ['ledgerReview'];
       //this.router.navigate(link);

    // comment this to include AU Authentication and deploy
   let validateUser = new User();

    validateUser.userId = this.userid;
    validateUser.password = this.password;
   validateUser.domainName = 'local';
   //if ( this.selectedDC)
   validateUser.businessUnitId = this.selectedDC;

    this.loginSvc.Authentication(validateUser)
      .then((response) => {
        console.log("ValidateUser "+ response);

        this.userName = response.firstName.concat(' ').concat(response.lastName);
        sessionStorage.setItem('loggedInUser', this.userName);
        sessionStorage.setItem('loggedInUserId', response.userId);
        sessionStorage.setItem('loggedInLanguage',this.selectedLang.value);//this.selectedLanguage
        sessionStorage.setItem('token',response.token);
        sessionStorage.setItem('securityId',response.securityId);
      console.log("Language  "+this.selectedLang.value);
const headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('WMT-Token', response.token);
        headers.append('WMT-Security-ID', response.securityId);
        headers.append('WMT-UserId', response.userId);
        headers.append('WMT-BusinessUnitID', this.selectedDC);
       // headers.append("Access-Control-Allow-Origin", "*");
        const options = new RequestOptions({headers: headers});
      //  const reqHeaders=new Headers(capabilityHeaders);
        this.loginSvc.CapabilityValidation(options)
        .then((response)=> {
          console.log('Capability  ' +JSON.stringify( response));
          console.log('Capability  capName' +JSON.stringify( response[3].capName));
        
          if ( response[3].capName === "017_001_PAMViewScree") {
            let link = ['ledgerReview'];
            this.router.navigate(link);
          }

          else {
            this.modal.alert().title('Error').body('You are not Authorized!').open();
                setTimeout(() => {
                }, 2000);
          }
        });
       
      })
      .catch(() => {
        console.error('Failed to Login');
          this.modal.alert().title('Error').body('You are not Authorized!').open();
                setTimeout(() => {
                }, 2000);
      });

  }

  getIsSupervisior(){
    const headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('WMT-USER-ID', this.userid);
       // headers.append('LANG-CODE',this.selectedLang.value),
        headers.append('COUNTRY-CODE' ,this.selectedDomain),
        headers.append('DC-NBR', this.selectedDC);
       // headers.append("Access-Control-Allow-Origin", "*");
        const options = new RequestOptions({headers: headers});

     this.loginSvc.GetSupervisor(options)
     .then((response) => {
       if(response===null)
       {
          sessionStorage.setItem('isSupervisor','false');
       }
       if(response!==null && response.associateDetails){
          sessionStorage.setItem('isSupervisor','true');
        }
     });
  }
}


export class User {
    domainName: string;
    password: string;
    userId: string;
   businessUnitId : string;
    
}

