import {MatMenuModule} from '@angular/material/menu';
import { Router } from '@angular/router';
import { async, ComponentFixture, TestBed,inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import {Http,HttpModule} from '@angular/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";
import { TimesheetComponent } from './timesheet.component';
import { AppComponent } from '../../app.component';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { TimesheetService } from './../../services/timesheet.service';
import { AssignShiftService } from '../../services/assign-shift.service';
import { AppCommonServices } from './../../services/app-common.services';
import {GetExceptionsService} from './../../services/exception.service';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
export function HttpLoaderFactory(httpClient: HttpClient) {
 //return new TranslateHttpLoader(httpClient, "assets/i18n/", ".txt"); // Local
   return new TranslateHttpLoader(httpClient, "/tpr/assets/i18n/", ".txt"); // Production
}

describe('TimesheetComponent', () => {
  let component: TimesheetComponent;
  let fixture: ComponentFixture<TimesheetComponent>;
let user={};
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TimesheetComponent ],
       schemas: [NO_ERRORS_SCHEMA],
        imports:[ 
       MatMenuModule,
       HttpModule,
       HttpClientModule, 
       HttpClientTestingModule, 
       TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
       }}),
      RouterTestingModule],
      providers:[TimesheetService, AssignShiftService, AppComponent, NavbarComponent,AppCommonServices,GetExceptionsService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimesheetComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('DCshift is called onload', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'setDCShift');
    component.setDCShift();
    expect(component.setDCShift).toHaveBeenCalled();
  }));

  it('search is called onload', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'search');
    component.search();
    expect(component.search).toHaveBeenCalled();
  }));
 
  it('handleUserUpdatedis called', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'handleUserUpdated');
    component.handleUserUpdated(user);
    expect(component.handleUserUpdated).toHaveBeenCalled();
  }));

   it('get Shift List ', inject([HttpClientModule,HttpClientTestingModule], () => {
    expect(component.ShiftList).toBeDefined();
  }));

   it('set shift Date ', inject([HttpClientModule,HttpClientTestingModule], () => {
        var yesterday = new Date(Date.now()- 864e5); // 864e5 == 86400000 == 24*60*60*1000  Date.now()
    var date ={ 
      year: yesterday.getFullYear(),
      month: (yesterday.getMonth() + 1),
      day: (yesterday.getDate())}
    expect(component.shiftDate).toEqual(date);
  }));

  //exportData
  it('export function called', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'exportData');
    component.exportData();
    expect(component.exportData).toHaveBeenCalled();
  }));

   it('delete function called', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'delete');
    component.delete();
    expect(component.delete).toHaveBeenCalled();
  }));

});