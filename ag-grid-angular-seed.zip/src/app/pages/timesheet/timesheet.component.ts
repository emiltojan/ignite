import { Component, OnInit, ViewChild } from '@angular/core';
import {IMyDpOptions,IMyDate, IMyDateModel} from 'mydatepicker';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { Modal } from 'ngx-modialog/plugins/bootstrap';
import { TimesheetService } from './../../services/timesheet.service';
import { AssignShiftService } from '../../services/assign-shift.service';
import { AppCommonServices } from './../../services/app-common.services';
import { AddAssociateComponent } from '../../components/add-associate/add-associate.component';
import { FilterByName, FilterById, FilterBySCC, FilterByDfltShift } from '../../components/filter/filter.component';
import { TimeSheetEditOptionsComponent } from '../../components/time-sheet-edit-options/time-sheet-edit-options.component';
import { AppComponent } from '../../app.component';
import { Router } from '@angular/router';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import {TranslateService} from '@ngx-translate/core';
import {EditRenderer} from './ad-grid-renderer/edit-renderer';
import { ShiftSetupService } from './../../services/shift-setup.service';
import {GetExceptionsService} from './../../services/exception.service';

@Component({
  selector: 'app-timesheet',
  templateUrl: './timesheet.component.html',
  styleUrls: ['./timesheet.component.css'],
  providers: [TimesheetService,ShiftSetupService,AssignShiftService, AppComponent, NavbarComponent,AppCommonServices,GetExceptionsService]
})
export class TimesheetComponent implements OnInit {
  AssociateDetails: any[] = [];
  ShiftList: any[] = [];
  paramDate:String;
  isEditEnable: boolean = false;
  userid: string;
  loading:boolean = false;
  submitted:boolean = false;
  columnDefs:any[]=[];
  gridOptions={};
  disableDelete:boolean=true;
  disabledSearch:boolean=false;
  showLoader:boolean=false;
  public exportOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: false,
    headers: (['Department', 'Associate Id', 'Associate Name', 'Shift', 'SCC','Clocked Hours']),
    showTitle: false,
    useBom: true,
  };
  FacilityList: any[] = [];
  selectedRows=[];
  pagesList:any[] = ['10','25','50','100'];
  private context;
  private frameworkComponents;
  private gridApi;
  private gridColumnApi;
  private paginationPageSize;
  icons:Object;
  private myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'mm/dd/yyyy',
        showTodayBtn:false,
        showClearDateBtn:false,
        markCurrentDay:true,
        maxYear:new Date().getFullYear(),
    };
  
  shiftDate:IMyDate = {year:0,month:0,day:0};
  private placeholder: string = 'mm/dd/yyyy';
  constructor(public service: TimesheetService, public assignShitService: AssignShiftService, private CommonServices:AppCommonServices,
   private router: Router,public shiftService: ShiftSetupService, private app: AppComponent, private navbar: NavbarComponent,public modal: Modal,private translate: TranslateService
	){
    translate.addLangs(["en", "ch"]);
    var yesterday = new Date(Date.now()- 864e5); // 864e5 == 86400000 == 24*60*60*1000  Date.now()
    this.shiftDate ={ 
      year: yesterday.getFullYear(),
      month: (yesterday.getMonth() + 1),
      day: (yesterday.getDate())}
    this.icons = { checkboxChecked:'<i style="color:rgb(0, 125, 198);font-size:18px"  class="fa fa-check"/>',
                filter:'<i class="fa fa-filter" style="font-size:18px"/>',
                menu:'<i style="display:none"/>'
              }
  
        
        this.gridOptions={
          suppressRowClickSelection:true,
          columnDefs: this.columnDefs,
          rowHeight:38,
          rowSelection:'multiple',
          paginationPageSize:parseInt(this.pagesList[0]),
          enableCellChangeFlash: true,
          suppressCellSelection:true
        }
    //this.paginationPageSize = 10;
     this.context={ componentParent : this};
     this.frameworkComponents= {
       editRenderer : EditRenderer,
       componentData:this
     };  
    if (sessionStorage.getItem('loggedInUser')) {
      navbar.loggedIn = true;
    }
    else {
      navbar.loggedIn = false;
      this.router.navigate(['']);
    }
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
     params.api.sizeColumnsToFit();
    params.api.paginationGoToPage();
  }
  getSelectedRow(event: any) {
   this.selectedRows = this.gridApi.getSelectedRows();
   if(this.selectedRows.length>0)
   {
      this.disableDelete=false;
   }else
   {
     this.disableDelete=true;
   }
   
 }

 generateTranslation() {

    this.translate.get('TimesheetScreen.Headers')
      .subscribe((res) => {
        var headerArr=[];
        headerArr.push(res.AssociateId);
        headerArr.push(res.Department);
        headerArr.push(res.Name);
        headerArr.push(res.Shift);
        headerArr.push(res.SCC);
        headerArr.push(res.OperationalArea);
        headerArr.push(res.WorkArea);
        headerArr.push(res.JobFunction);
        headerArr.push(res.Time);
        headerArr.push(res.Facility);
        headerArr.push(res.SupervisorID);
        console.log('headers-->',headerArr);
        this.exportOptions.headers=(headerArr);
        let parseData = this.parseData(res);
        this.columnDefs = parseData.columnDefs;
        if (sessionStorage.getItem('loggedinDomain') === 'MX') {
          this.columnDefs.splice(10,1);
        }
      },
       err => {
          console.log("Unable to retrive Timesheet Headers");
        });
      
  }
  parseData(data) {
    var hideFacility=false;
    let parseData = {
     columnDefs :[
  {headerName:"",headerCheckboxSelection: true,minWidth:80,checkboxSelection: true,icons: { checkboxChecked:'<i style="color:rgb(0, 125, 198);font-size:18px"  class="fa fa-check-square"/>'} ,suppressFilter:true},
            {headerName: data.AssociateId,field: "associateId",minWidth:150,cellClass: 'my-class'},
            {headerName: data.Department, field: "deptDesc",minWidth:150,cellClass: 'my-class'},
            {headerName: data.Name, field: "name",minWidth:150},
            {headerName: data.Shift, field: "shiftCode",minWidth:150},
            {headerName: data.SCC, field: "supplyChainCd",minWidth:150},
            {headerName: data.OperationalArea, field: "opAreaDesc",minWidth:180},
            {headerName: data.WorkArea, field: "workAreaDesc",minWidth:180},
            {headerName: data.JobFunction, field: "jobFunctionDesc",minWidth:180},
            {headerName: data.Time, field:"totalClockedIntime",minWidth:150},
            {headerName:data.Facility,field:"facilityAreaCode",minWidth:150},
            {headerName:data.SupervisorID, field: "supervisorUserId",minWidth:180},
            {headerName:data.edit,cellRenderer:"editRenderer",minWidth:100,suppressFilter:true,}
], 
    }
    return parseData;
  }
  ngOnInit() {
    this.generateTranslation();
    // var date = new Date();
    // let str = date.getDate();
    // console.log(str.toString().length);
    // if (str.toString().length == 1) {
    //   this.shiftDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-0' + (date.getDate()); 
    // } else {
    //   this.shiftDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + (date.getDate());
    // }
  // if(sessionStorage.getItem('TimesheetDate')){
  //       this.shiftDate = sessionStorage.getItem('TimesheetDate')
  //      }
      
  this.setDCShift();
  this.setFacility();
  this.search();      
  }
   @ViewChild(AddAssociateComponent) AddAssociateChild: AddAssociateComponent;
  @ViewChild(TimeSheetEditOptionsComponent) TimeSheetEditOptionsChild: TimeSheetEditOptionsComponent;
  @ViewChild('pagesize') pagesize;

   onDateChanged(event: IMyDateModel) {
        // Update value of selDate variable
        console.log(event.date);
          this.shiftDate = event.date;            
    }
    clearDate() {
        this.shiftDate ={year:0,month:0,day:0};
    }
  show(value: boolean) {
    this.AddAssociateChild.showModalBox(value, true);
  }

  onPageSizeChanged() {
    this.gridApi.paginationSetPageSize(Number(this.pagesize.nativeElement.value));
  }

  showEditOptions(data) {
    this.TimeSheetEditOptionsChild.showModalBox(data);
  }


  exportData() {
    var exportData: any[] =[];
    console.log("Timesheet " + JSON.stringify(this.AssociateDetails));
    for (let j = 0; j < this.AssociateDetails.length; j++) {   
      exportData[j] = {
      "AssociateId" : this.AssociateDetails[j].associateId==undefined?'':this.AssociateDetails[j].associateId,
      "Department" : this.AssociateDetails[j].deptDesc==undefined?'':this.AssociateDetails[j].deptDesc,
      "associateName" :  this.AssociateDetails[j].name==undefined?'':this.AssociateDetails[j].name,
      "dfltShiftNbr" : this.AssociateDetails[j].shiftCode==undefined?'':this.AssociateDetails[j].shiftCode,//dfltShiftNbr,
      "supplyChainCd" : this.AssociateDetails[j].supplyChainCd==undefined?'':this.AssociateDetails[j].supplyChainCd,
      "opAreaDesc" : this.AssociateDetails[j].opAreaDesc==undefined?'':this.AssociateDetails[j].opAreaDesc,
      "workAreaDesc" : this.AssociateDetails[j].workAreaDesc==undefined?'':this.AssociateDetails[j].workAreaDesc,
      "jobFunctionDesc" : this.AssociateDetails[j].jobFunctionDesc==undefined?'':this.AssociateDetails[j].jobFunctionDesc,
      "totalClockedIntime"  : this.AssociateDetails[j].totalClockedIntime==undefined?'':this.AssociateDetails[j].totalClockedIntime,
      "facilityAreaCode":this.AssociateDetails[j].facilityAreaCode==undefined?'':this.AssociateDetails[j].facilityAreaCode,
      "supervisorUserId":this.AssociateDetails[j].supervisorUserId==undefined?'':this.AssociateDetails[j].supervisorUserId,                        
      };
    } 
    new Angular2Csv(exportData, 'TimeSheetData', this.exportOptions);
  }

  setDCShift(){
    this.assignShitService.getShiftsList()
      .subscribe((ShiftDetails:any) => {
        if(ShiftDetails!==null)
        {
          if(ShiftDetails!==undefined &&ShiftDetails.dcShift!==undefined){
            this.ShiftList = ShiftDetails.dcShift;
          }
          
        }
      },(err)=>{
        console.error('failed to retrieve shift details');
      }); 
  }

  setFacility(){
    this.shiftService.getFacility()
      .subscribe((FacilityData:any) => {
        if(FacilityData!==null){
          this.FacilityList = FacilityData.FacilityTO;
        }
      },(err)=>{
        console.error('failed to retrieve associate data');
      });
      console.log('this.FacilityList-->',this.FacilityList)
  }

  search() {
    console.log('date-->',this.shiftDate);
   this.paramDate=this.shiftDate.year+'/'+this.shiftDate.month+'/'+this.shiftDate.day;
   // sessionStorage.setItem('TimesheetDate',this.shiftDate);
    var searchDate =this.paramDate;//this.shiftDate.replace(/-/g , "/");
    this.showLoader=true;
    this.loading = true; 
    this.submitted = false;
    this.service.AssociateDetails(searchDate)
      .subscribe((AssociateData:any) => {
        if (AssociateData!==null) {
            this.AssociateDetails=[];
          if(Array.isArray(AssociateData.associateDetails))
          {
            this.AssociateDetails = AssociateData.associateDetails;
          }else
          {
            this.AssociateDetails=[AssociateData.associateDetails];
          }
           for(var i=0;i<this.AssociateDetails.length;i++)
            {
              this.AssociateDetails[i].name=this.AssociateDetails[i].firstName +' '+ this.AssociateDetails[i].lastName;
              this.AssociateDetails[i].facilityTo=this.FacilityList;
            }
        }else{
          this.AssociateDetails =[];
        }
        this.showLoader=false;
        this.loading = false; 
         this.submitted = true;
      },(err)=>{
        this.showLoader=false;
        this.loading = false;
         this.submitted = true;
        this.AssociateDetails  =[];
        console.error('failed to retrieve timesheet data');
      });
      
  }
  delete(){
    var searchDate = this.paramDate;
     var temp=[];
    if(Array.isArray(this.selectedRows))
    {

      for(var k=0;k<this.selectedRows.length;k++)
      {
        var List={
        attendClockDate:searchDate,
        associateId :this.selectedRows[k].associateId
        }
        temp.push(List);
      }
      
    }
    var dataList={
      associateDetails:temp
    }
    console.log('selectedRows-->',dataList);
    const dialog = this.modal.confirm()
    .size('sm')
    .isBlocking(true)
    .showClose(false)
    .keyboard(27)
    .okBtn('Confirm')
    .title('Confirm Delete')
    .headerClass('modal-header headerAlgn')
    .footerClass('modal-footer alignBtn')
    .body("Delete selected attendance records?")
    .open();

 dialog.then( dialogRef => {
           dialogRef.result.then( result => {//${result}
    this.service.DeleteAssociateDetails(dataList)
    .subscribe((res:any)=>{
      this.disableDelete=true;
      this.search()
      console.log('Success')},
      (err)=>{
      console.log('Error Occured')
    })

          }, (err)=>{});
       });       
                  setTimeout(() => {
                  }, 2000);
  }

  handleUserUpdated(user) {
    console.log('gggggg');
    //  var date = new Date();   
    //  this.AssociateDetails= []; 
    // let str = date.getDate();    
    // if (str.toString().length == 1) {
    //   this.shiftDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-0' + date.getDate();
    // } else {
    //   this.shiftDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    // }
    this.search();
  }
}
