import {MatMenuModule} from '@angular/material/menu';
import { Router } from '@angular/router';
import { async, ComponentFixture, TestBed,inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import {Http,HttpModule} from '@angular/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";
import { ProductivityComponent } from './productivity.component';
import {IMyDpOptions,IMyDate, IMyDateModel} from 'mydatepicker';
import { AppComponent } from '../../app.component';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { ProductivityService } from './../../services/productivity.service';
import { ShiftSetupService } from './../../services/shift-setup.service';
import { TimesheetService } from './../../services/timesheet.service';
import { AssignShiftService } from '../../services/assign-shift.service';
import { AppCommonServices } from './../../services/app-common.services';
import {GetExceptionsService} from './../../services/exception.service';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
export function HttpLoaderFactory(httpClient: HttpClient) {
 //return new TranslateHttpLoader(httpClient, "assets/i18n/", ".txt"); // Local
   return new TranslateHttpLoader(httpClient, "/tpr/assets/i18n/", ".txt"); // Production
}

describe('ProductivityComponent', () => {
  let component: ProductivityComponent;
  let fixture: ComponentFixture<ProductivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductivityComponent ],
       schemas: [NO_ERRORS_SCHEMA],
        imports:[ 
       MatMenuModule,
       HttpModule,
       HttpClientModule, 
       HttpClientTestingModule, 
       TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
       }}),
      RouterTestingModule],
      providers: [ProductivityService, ShiftSetupService, AssignShiftService, NavbarComponent,GetExceptionsService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductivityComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call exportData method',function(){
     spyOn(component,"exportData");
  component.exportData();
  expect(component.exportData).toHaveBeenCalled();
});

 it('should call onassociatePageSizeChanged method',function(){
     spyOn(component,"onassociatePageSizeChanged");
  component.onassociatePageSizeChanged();
  expect(component.onassociatePageSizeChanged).toHaveBeenCalled();
});

it('should call onteamPageSizeChanged method',function(){
     spyOn(component,"onteamPageSizeChanged");
  component.onteamPageSizeChanged();
  expect(component.onteamPageSizeChanged).toHaveBeenCalled();
});
  
  it('should call searchAssociateProd method',function(){
     spyOn(component,"searchAssociateProd");
  component.searchAssociateProd();
  expect(component.searchAssociateProd).toHaveBeenCalled();
});

 it('should call searchTeamProd method',function(){
     spyOn(component,"searchTeamProd");
  component.searchTeamProd();
  expect(component.searchTeamProd).toHaveBeenCalled();
});




});

function testData(){
  return {
    date :'02/20/2018',
    data :'dummy',
    event :{
      charCode:'52'
    }
  }
}
