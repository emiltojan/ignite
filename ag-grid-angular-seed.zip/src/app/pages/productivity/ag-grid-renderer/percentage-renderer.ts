import {Component, OnDestroy} from "@angular/core";
import {ICellRendererAngularComp} from "ag-grid-angular";



@Component({
    selector: 'percentage-renderer',
    template: `<div class="progress" style="margin-top:12px">
    <div [ngClass]="classSelector()" class="progress-bar  progress-bar-striped active" role="progressbar" 
    [style.width.%]= "(calculatePercentage()>100) ? '100' : calculatePercentage()" >
     {{calculatePercentage()+'%'}}
    </div>
  </div>`,
    providers:[]      
})
export class PercentageRenderer implements ICellRendererAngularComp, OnDestroy {

    private params: any;

    classSelector()
    {
        if (this.calculatePercentage() < 75) {
            return 'progress-bar-danger';
        } else if (this.calculatePercentage() > 75 && this.calculatePercentage() < 95){

            return 'progress-bar-warning';
        } else  {
            return 'progress-bar-success';
        }
        
    }

    constructor()
    {
        
    }

    agInit(params: any): void {
        this.params = params;
        console.log(this.params);   

        console.log(this.calculatePercentage());
    }



    ngOnDestroy() {
        console.log(`Destroying percentage-renderer`);
    }

    refresh(): boolean {
        return false;
    }

    calculatePercentage = () => 
    {
    let percentage = Math.round((this.params.data.volumePerHour/this.params.data.goal)* 100);
     return percentage;
    }
}