import {Component, OnDestroy} from "@angular/core";
import {ICellRendererAngularComp} from "ag-grid-angular";
import { ProductivityService } from './../../../services/productivity.service';


@Component({
    selector: 'volume-renderer',
    template: `<input type="text"
                (keypress)="onKeyPressNumber($event)" [(ngModel)]="params.data.volume"
                (blur)="modifyAssociateVolume(params.data)">`,
    providers: [ProductivityService]      
})
export class VolumeRenderer implements ICellRendererAngularComp, OnDestroy {

    private params: any;

    constructor(private service: ProductivityService)
    {
        
    }

    agInit(params: any): void {
        this.params = params;
        console.log(this.params);
    }

    public valueSquared(): number {
        return this.params.value * this.params.value;
    }

    ngOnDestroy() {
        console.log(`Destroying SquareComponent`);
    }

    refresh(): boolean {
        return false;
    }

onKeyPressNumber(event) { 
    return event.charCode >=48 && event.charCode <= 57;
  }

  modifyAssociateVolume(data) {
    // data["rptDate"] = this.shiftDate; 
   if( this.params.value !== this.params.data.volume)
   {
    console.log("modifyAssociateVolume", data);
    this.service.modifyVolume(data)
      .subscribe((res) => {
        console.log(res);
        // this.showVolumeUpdateMessage = true;
      },(err)=>{
         console.error('failed to update volume'); 
      });
    //   .catch(() => {
    //     console.error('failed to update volume');
    //   });
   }
  }
}
