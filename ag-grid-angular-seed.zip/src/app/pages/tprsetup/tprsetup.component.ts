import { Component, OnInit, ViewChild ,ElementRef,OnDestroy} from '@angular/core';
import 'rxjs/add/operator/takeUntil';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { AddAssociateComponent } from '../../components/add-associate/add-associate.component';
import { ShiftSetupService } from '../../services/shift-setup.service';
import { AssignShiftService } from '../../services/assign-shift.service';
import { AssignShiftComponent } from '../../components/assign-shift/assign-shift.component';
import { FilterByName, FilterById, FilterBySCC, FilterByDfltShift, FilterByDfltFacility } from '../../components/filter/filter.component';
import { AppComponent } from '../../app.component';
import { Router } from '@angular/router';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import {GetExceptionsService} from './../../services/exception.service';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import {TranslateService} from '@ngx-translate/core';
import {GridOptions} from 'ag-grid/main';

var userid: string;

@Component({
  selector: 'app-tprsetup',
  templateUrl: './tprsetup.component.html',
  styleUrls: ['./tprsetup.component.css'],
  providers: [ShiftSetupService, AssignShiftService, AppComponent, NavbarComponent,GetExceptionsService]
})
export class TprsetupComponent implements OnInit,OnDestroy {
  AssociateDetails: any[] = [];
  ShiftList: any[] = [];
  FacilityList: any[] = [];
  //private isSelected: boolean = false;
  isDisabled: boolean = true;
  shiftNum:any;
  selectedDetails: any[] = [];
  CreditOffice:any;
  Whse:any;
  
  PO_Type:any;
  Bank:any;
  loading:boolean = true;
  rowData:any[]=[];
  selectedshift :any;
  columnDefs:any[]=[];
  gridOptions:GridOptions;
  assignRecords:any[]=[];
  showLoader:boolean=false;
  icons:Object;
  date :any;
  private gridApi;
  private gridColumnApi;
  private paginationPageSize;
  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  public exportOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: false,
    headers: [],
    showTitle: false,
    useBom: true
  };
headers_MX :any[]=['Department', 'Supervisor Id', 'Associate Id', 'Associate Name', 'Associate Type','GLS Id','Shift','Shift Effective From','Default Job Code'];
  headers_CN :any[]=['Department', 'Supervisor Id', 'Associate Id', 'Associate Name', 'Associate Type','GLS Id','Facility','Shift','Shift Effective From','Default Job Code'];
pagesList:any[] = ['10','100','500','1000'];

  

  constructor(public service: ShiftSetupService, public assignShitService: AssignShiftService,
    private router: Router, private app: AppComponent, private navbar: NavbarComponent, 
		private translate: TranslateService) {
    
  this.gridOptions ={
paginationPageSize :parseInt(this.pagesList[0]),
columnDefs: this.columnDefs,
suppressCellSelection:true

};
    //this.gridOptions.suppressHorizontalScroll=false;
    this.paginationPageSize = 10;
        this.columnDefs = [];

this.icons = { checkboxChecked:'<i style="color:rgb(0, 125, 198);font-size:18px"  class="fa fa-check"/>',
filter:'<i class="fa fa-filter" style="font-size:18px"/>',
 menu:'<i style="display:none"/>'
              }

// this.icons = { checkboxChecked:'<i style="color:rgb(0, 125, 198);font-size:18px"  class="fa fa-check"/>',
//                 filter:'<i class="fa fa-filter" style="font-size:18px"/>',
//                 menu:'<i style="display:none"/>'
//               }    
    translate.addLangs(["en", "ch"]);
    
    if (sessionStorage.getItem('loggedInUser')) {
      navbar.loggedIn = true;
    }
    else {
      navbar.loggedIn = false;
      this.router.navigate(['/login']);
    }
  }

  generateTranslation() {

    this.translate.get('ShiftSetup.Headers')
      .subscribe((res) => {
        let parseData = this.parseData(res);
        this.columnDefs = parseData.columnDefs;
        if (sessionStorage.getItem('loggedinDomain') === 'MX') {
          this.columnDefs.splice(7,1);
        }
      },
       err => {
          console.log("Unable to retrive TPR Headers");
        });
      
  }

  parseData(data) {
console.log('parseData ' + JSON.stringify(data));
    let parseData = {
      columnDefs: [
            {headerName:"",headerCheckboxSelection: true,minWidth:80, suppressFilter:true,checkboxSelection: true,icons: { checkboxChecked:'<i style="color:rgb(0, 125, 198);font-size:18px"  class="fa fa-check-square"/>'} },
            {headerName: "", field: "deptDesc",minWidth: 150,cellStyle: {border:'0px' }},
            {headerName: "", field: "supervisorUserId",minWidth: 180,cellStyle: {border:'0px' }},
            {headerName: "", field: "associateId",minWidth: 150,cellStyle: {border:'0px' }},
            {headerName: "", field: "name",minWidth: 150,cellStyle: {border:'0px' }},
            {headerName: "", field: "assocTypeCode",minWidth: 180,cellStyle: {border:'0px' }},
            {headerName: "", field: "glsUserid",minWidth: 150,cellStyle: {border:'0px' }},
            {headerName: "", field: "facilityAreaCode",minWidth: 150,cellStyle: {border:'0px' }},
            {headerName: "", field: "shiftCode",minWidth: 150,cellStyle: {border:'0px' }},
            {headerName: "", field: "shiftEffectiveDate",minWidth: 150,cellStyle: {border:'0px' }},
            {headerName: "", field: "supplyChainCd",minWidth: 150,cellStyle: {border:'0px' }},
            
  ], 
    }

    parseData.columnDefs[1].headerName = data.DeptNbr;
    parseData.columnDefs[2].headerName = data.SupervisorUserId;
    parseData.columnDefs[3].headerName = data.AssociateId;
    parseData.columnDefs[4].headerName = data.Name;
    parseData.columnDefs[5].headerName = data.AssocTypeCode;
    parseData.columnDefs[6].headerName = data.GlsUserid;
    parseData.columnDefs[7].headerName = data.FacilityArea;
    parseData.columnDefs[8].headerName = data.ShiftCode;
    parseData.columnDefs[9].headerName = data.ShiftEffectiveDate;
    parseData.columnDefs[10].headerName = data.SupplyChainCd;

    
    return parseData;
  }


  onGridReady(params) {
        this.gridApi=params.api;
        this.gridColumnApi=params.columnApi;
        params.api.sizeColumnsToFit();
        params.api.paginationGoToPage(4);
    }

    selectAllRows() {
        this.gridOptions.api.selectAll();
    }
  ngOnInit() {
    //this.showLoader=true;
    this.date=new Date();
    this.selectedshift=1;
     this.assignShitService.getShiftsList()
      .subscribe((ShiftDetails:any) => {
        if(ShiftDetails!==null)
        {
          this.ShiftList = ShiftDetails.dcShift;
        }
      },(err)=>{
        console.error('failed to retrieve shift details');
      });
    this.service.getFacility()
      .subscribe((FacilityData:any) => {
        if(FacilityData!==null)
        {
            this.FacilityList = FacilityData.FacilityTO;
        console.log("FacilityList "+JSON.stringify(this.FacilityList));
        } 
      },(err)=>{
        this.showLoader=false;
        console.error('failed to retrieve associate data');
      });
   
    this.generateTranslation();
  } 
  ngOnDestroy() {
        console.log(`Destroying percentage-renderer`);
        this.destroyed$.next(true);
        this.destroyed$.complete();
    }

  @ViewChild(AddAssociateComponent) AddAssociateChild: AddAssociateComponent;
  @ViewChild(AssignShiftComponent) AssignShiftChild: AssignShiftComponent;
  @ViewChild('pagesize') pagesize;

  show(value: boolean) {
    this.AddAssociateChild.showModalBox(value, true);
  }

  addAssociat(value: boolean) {
    this.AddAssociateChild.showModalBox(value, false);
  }

  assignShift(){   
    this.AssignShiftChild.showModalBox(this.selectedDetails);    
  }

  //  onPageSizeChanged(page) {
  //   this.gridApi.paginationSetPageSize(page);
  // }


  onPageSizeChanged() {
    this.gridApi.paginationSetPageSize(Number(this.pagesize.nativeElement.value));
  }

  getSelectedRow(event: any) {
   this.selectedDetails = this.gridApi.getSelectedRows();
   if(this.selectedDetails.length>0)
   {
      this.isDisabled=false;
   }else
   {
     this.isDisabled=true;
   }
   
  }

  exportData() {   
   var exportData: any[] =[];
   this.exportOptions.headers = [];
   if (sessionStorage.getItem('loggedinDomain') === 'MX') {
        this.exportOptions.headers.push(this.headers_MX);
         for (let j = 0; j < this.AssociateDetails.length; j++) {   
       exportData[j] = {
        "DeptNbr" : this.AssociateDetails[j].deptDesc,
        "supervisorUserId":this.AssociateDetails[j].supervisorUserId,
        "associateId" : this.AssociateDetails[j].associateId,
      "name" :  this.AssociateDetails[j].firstName + ' ' + this.AssociateDetails[j].lastName,
      "assocTypeCode" : this.AssociateDetails[j].assocTypeCode,
      "glsUserid" : this.AssociateDetails[j].glsUserid,
      "shiftCode"  : this.AssociateDetails[j].shiftCode ,    
      "shiftEffectiveDate" : this.AssociateDetails[j].shiftEffectiveDate,                          
      "supplyChainCd" : this.AssociateDetails[j].supplyChainCd ,
      };
    }
  } else {
        this.exportOptions.headers.push(this.headers_CN);
        for (let j = 0; j < this.AssociateDetails.length; j++) {   
        exportData[j] = {
        "DeptNbr" : this.AssociateDetails[j].deptDesc==undefined?'':this.AssociateDetails[j].deptDesc,
        "supervisorUserId":this.AssociateDetails[j].supervisorUserId==undefined?'':this.AssociateDetails[j].supervisorUserId,
        "associateId" : this.AssociateDetails[j].associateId==undefined?'':this.AssociateDetails[j].associateId,
      "name" :  this.AssociateDetails[j].firstName==undefined?'':this.AssociateDetails[j].firstName + ' ' + this.AssociateDetails[j].lastName==undefined?'':this.AssociateDetails[j].lastName,
      "assocTypeCode" : this.AssociateDetails[j].assocTypeCode==undefined?'':this.AssociateDetails[j].assocTypeCode,
      "glsUserid" : this.AssociateDetails[j].glsUserid==undefined?'':this.AssociateDetails[j].glsUserid,
      "facilityAreaCode" : this.AssociateDetails[j].facilityAreaCode==undefined?'':this.AssociateDetails[j].facilityAreaCode,
      "shiftCode"  : this.AssociateDetails[j].shiftCode==undefined?'':this.AssociateDetails[j].shiftCode ,   
      "shiftEffectiveDate" : this.AssociateDetails[j].shiftEffectiveDate==undefined?'':this.AssociateDetails[j].shiftEffectiveDate,                            
      "supplyChainCd" : this.AssociateDetails[j].supplyChainCd==undefined?'':this.AssociateDetails[j].supplyChainCd 
      };
    }
      }       
    console.log('exported data', exportData);
    new Angular2Csv(exportData, 'AssociateDetails', this.exportOptions);
  }

  checkAll() {
    //this.isSelected = !this.isSelected;
    this.AssociateDetails.map(function(data, index) {
      data.checkBoxValue = !data.checkBoxValue;
    });

    this.isDisabled = this.isDisabled ? this.isDisabled : !this.isDisabled;
  }

  test(data)
  {
    console.log(data);  
  }

  onSelect(data, value){
    console.log(data);
    if(value){
      this.isDisabled= true;
      this.selectedDetails.push(data);
    }
    console.log(this.selectedDetails);
  }

  getAssociate(){
    this.service.getAssociate()
      .subscribe((AssociateData:any) => {
        console.log(AssociateData);
        if(AssociateData!==null)
        {
          if (AssociateData.associateDetails.length) {
          this.AssociateDetails = AssociateData.associateDetails;
        } else {
          this.AssociateDetails = [AssociateData.associateDetails];
        }        
        console.log(this.AssociateDetails);
        for(var i=0;i<this.AssociateDetails.length;i++)
        {
          this.AssociateDetails[i].name=this.AssociateDetails[i].firstName +' '+ this.AssociateDetails[i].lastName;
          if(this.AssociateDetails[i]['shiftEffectiveDate'])
          {
               var dat = new Date(this.AssociateDetails[i].shiftEffectiveDate);
           this.AssociateDetails[i].shiftEffectiveDate=(dat.getMonth()+1) +'/' +(dat.getDate()+1) +'/'+dat.getFullYear();
          }else{
            this.AssociateDetails[i].shiftEffectiveDate="";
          }
         
        }
        console.log(this.AssociateDetails);
        this.loading = false;
         this.showLoader=false;
        }else{
          console.log('Error Occured');
        }
        
      },(err)=>{
        console.error('failed to retrieve associate data');
      })
      // .catch(() => {
      //   console.error('failed to retrieve associate data');
      // });
  }

  handleUserUpdated(user) {
    this.getAssociate();
  }

  getPODetails(){
this.showLoader=true;
    this.selectedshift ="2";
    this.shiftNum = "3";
    this.CreditOffice="Walmart";
    this.Whse="Whse";
    this.PO_Type="PoType";
    this.Bank="Bank Of America";
    
     this.getAssociate();
     this.showLoader=false;
  }

}
