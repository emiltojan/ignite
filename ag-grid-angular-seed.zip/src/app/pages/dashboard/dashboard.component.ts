import { Component, OnInit,Output,ElementRef,ViewChild} from '@angular/core';
import * as Chartist from 'chartist';
import { Router } from '@angular/router';
import {IMyDpOptions,IMyDate, IMyDateModel} from 'mydatepicker';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import{ViewDetailsComponent} from './../../pages/view-details/view-details.component';
import { AssignShiftService } from './../../services/assign-shift.service';
import { DashboardService } from './../../services/dashboard.service';
import {FormControl,Validators} from '@angular/forms';
import { DoughnutChartComponent, PieChartComponent, BarChartComponent } from 'angular-d3-charts'; 
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {Http, Headers, RequestOptions} from '@angular/http';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  providers: [AssignShiftService,DashboardService]
})
export class DashboardComponent implements OnInit {
  userid: string;
  ShiftList: any[] = [];
  date :any;
  dateVal:any;
  AllShifts:any;
  performanceDetails:any={};
  overAllDetails:any={};
  shiftNum='';
  myTeamDetails:any={}; 
  showProgress:boolean=false;
  public doughnutChartLabels:string[] = ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'];
  public doughnutChartData:number[] = [];
  public doughnutOptions :any;
  width=200;
  height=100;
  outerRadius=70;
  innerRadius=30;
  middleText :number=20;
  metgoals:number;
  unmetgoals:number;
  receivingProductivityColor:any;
  orderFillingProductivityColor :any;
  shippingProductivityColor :any;
  fixedFunctionsProductivityColor : any;
  receivingArrowType :any;
  orderFillingArrowType :any;
  shippingArrowType :any ;
  fixedFunctionsArrowType :any;
  arrowType:any;
  showLoader:boolean=true;
  showJoblist:boolean=false;
  minDate = new Date(2000, 0, 1);
  maxDate = new Date();
  showReceiving:boolean;
  showOrderFilling:boolean;
  showShipping:boolean;
  showFixing:boolean;
  showMyTeam:boolean=false;
  showMyTeamPerf:boolean=false;
  selectedShift :any = "test";
  
  public doughnutChartColor : any[] =[
    {
    backgroundColor:["#76c043","#f18c85"]
  }];
  public doughnutChartType:string = 'doughnut';
  horizontalChartColors : any[] =[
    {
    backgroundColor:["#76c043","#f18c85"]
  }];
  public donutChartData = [{
    id: 0,
    value: 20,
    color: 'red',
  },
   {
    id: 1,
    value: 30,
    color: 'green',
  }];

   public barChartData:any[] = [
    {data: [65, 59, 80, 81, 56, 55, 40]},
    {data: [28, 48, 40, 19, 86, 27, 90]}
  ];
    public barChartType ='horizontalBar';
    public barChartOptions:any = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  private shiftDate: IMyDate = {year:0,month:0,day:0};
  jobDetailList:any=[];
@Output() 
  emitDate = new EventEmitter();
  constructor(private router: Router,private translate: TranslateService,public assignShitService: AssignShiftService,public dashboardService:DashboardService,http: Http) {
     translate.addLangs(["en", "ch"]);
		translate.setDefaultLang(sessionStorage.getItem('loggedInLanguage').valueOf());
    const browserLang = translate.getBrowserLang();
   // translate.use(browserLang.match(/en|ch/) ? browserLang : 'en');
  }
 //  @ViewChild(ViewDetailsComponent) viewDetailsComponent: ViewDetailsComponent;
 //@ViewChild('checkWidth')elementView: ElementRef;
  @ViewChild ('plannedHrs')plannedHrs: ElementRef;
  @ViewChild('actualHrs')actualHrs:ElementRef;
  ngOnInit() {
    var yesterday = new Date(Date.now()- 864e5); // 864e5 == 86400000 == 24*60*60*1000  Date.now()
    this.maxDate = yesterday;
    this.date = new FormControl(yesterday);
    this.AllShifts=new FormControl("All Shifts");
    this.metgoals=14;
    this.unmetgoals=6;
    this.doughnutOptions={
      cutoutPercentage:70
    }

    
   const headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('WMT-USER-ID', sessionStorage.getItem('loggedInUserId'));
        headers.append('LANG-CODE','101'),
        headers.append('COUNTRY-CODE' ,'MX'),
        headers.append('DC-NBR', '07494');
       // headers.append("Access-Control-Allow-Origin", "*");
        const options = new RequestOptions({headers: headers});

    //  this.dashboardService.GetSupervisor(options)
    //  .then((response) => {
    //    if (response) {
    //    this.supervisorId=response.associateDetails.supervisorUserId;
    //    }

    //  });
     this.assignShitService.getShiftsList()
      .subscribe((ShiftDetails:any) => {
        if(ShiftDetails!==null)
        {
          if(ShiftDetails!==undefined&&ShiftDetails.dcShift!==undefined)
          {
            this.ShiftList=[];
            console.log('ShiftDetails'+JSON.stringify(ShiftDetails));
        this.ShiftList = ShiftDetails.dcShift;
        console.log('ShiftList' + JSON.stringify(this.ShiftList));
        this.shiftNum='0';//this.ShiftList[0].shiftCode;
        this.selectedShift="test";
        var yesdyDate = new Date(yesterday);
        var date1=yesdyDate.getFullYear()+'/'+(yesdyDate.getMonth()+1)+'/'+yesdyDate.getDate();
        this.dateVal=date1;
        this.callDashBoard(date1,this.shiftNum);
          }
        }
        
      },(err)=>{
        console.error('failed to retrieve shift details');
      });
      
  }//ngOnInit ends
  


   
    getWidth(val1,val2){
      var temp=((val2*100)/val1);
      return temp;

    }
    onDateChange(event){
      var yesdyDate = new Date(event.targetElement.value);
      var date1=yesdyDate.getFullYear()+'/'+(yesdyDate.getMonth()+1)+'/'+yesdyDate.getDate();
      this.dateVal=date1;
      console.log("OnDateChangeCall");
      this.callDashBoard(date1,this.shiftNum);
    }
    onChange(val){
      this.callDashBoard(this.dateVal,val);
    }
     callDashBoard(date,shift){
      this.dashboardService.overAllPerformance(date,shift)
      .subscribe((overAllData:any)=>{
        if(overAllData!==null)
        {
          this.showLoader=false;
          this.overAllDetails=overAllData;
          if(this.overAllDetails['receiving']){
            this.showReceiving=true;
            this.receivingProductivityColor=this.overAllDetails.receiving.prodFrmPrevDay.substring(0,1) === '-' ? "#e93221" : "#81c74c";
            this.receivingArrowType= this.overAllDetails.receiving.prodFrmPrevDay.substring(0,1) === '+' ? "arrow_upward" : "arrow_downward";
          }else{this.showReceiving=false};
          if(this.overAllDetails['orderFilling'])
          {
            this.showOrderFilling=true;
            this.orderFillingProductivityColor = this.overAllDetails.orderFilling.prodFrmPrevDay.substring(0,1) === '-' ? "#e93221" : "#81c74c";
            this.orderFillingArrowType= this.overAllDetails.orderFilling.prodFrmPrevDay.substring(0,1) === '+' ? "arrow_upward" : "arrow_downward";
          }else{this.showOrderFilling=false;}
          if(this.overAllDetails['shipping'])
          {
            this.showShipping=true;
            this.shippingProductivityColor = this.overAllDetails.shipping.prodFrmPrevDay.substring(0,1) === '-' ? "#e93221" : "#81c74c";
            this.shippingArrowType= this.overAllDetails.shipping.prodFrmPrevDay.substring(0,1) === '+' ? "arrow_upward" : "arrow_downward";
          }else{this.showShipping=false;}
         // this.setSymbolSigns(this.overAllDetails.receiving.prodFrmPrevDay);
           if(this.overAllDetails['fixedFunction'])
          {
            this.showFixing=true;
            this.fixedFunctionsProductivityColor =this.overAllDetails.fixedFunction.prodFrmPrevDay.substring(0,1) === '-' ? "#e93221" : "#81c74c";
            this.fixedFunctionsArrowType= this.overAllDetails.fixedFunction.prodFrmPrevDay.substring(0,1) === '+' ? "arrow_upward" : "arrow_downward";
          }else{this.showFixing=false;}
          
          
          

        }},
            (err)=>{
              this.showLoader=false;
              console.error('Error Ocurred')});
              
        if(sessionStorage.getItem('isSupervisor')==='true') {
          this.showMyTeam=true;
          this.callMyTeamPerformance(date,shift);
        }
        else{
          this.showMyTeam=false;
        }
       
    }
    callMyTeamPerformance(date,shift){
       this.dashboardService.myTeamPerformance(date,shift)
        .subscribe((myTeamData)=>{
          if(myTeamData!==null)
          {
            this.showLoader=false;
            this.myTeamDetails=myTeamData;
           this.jobDetailList=this.myTeamDetails.associateProdList;
            if(Array.isArray(this.jobDetailList))
            {
              this.jobDetailList=this.myTeamDetails.associateProdList;
              this.showJoblist=true;
              this.showMyTeamPerf=true;
            }else{
              this.jobDetailList=[];
              this.jobDetailList.push(this.myTeamDetails.associateProdList);
              this.showJoblist=true;
              this.showMyTeamPerf=true;
            }
            for(var i=0;i<this.jobDetailList.length;i++)
            {
              var total=parseInt(this.jobDetailList[i].aboveExpect) + parseInt(this.jobDetailList[i].belowExpect);
              var s1=this.getWidth(total,parseInt(this.jobDetailList[i].aboveExpect));
              var s2=this.getWidth(total,parseInt(this.jobDetailList[i].belowExpect));
              this.jobDetailList[i].above=Math.round(s1).toString()+'%';
              this.jobDetailList[i].below=Math.round(s2).toString()+'%';
              this.jobDetailList[i].goalCompletion=Number(this.jobDetailList[i].goalCompletion).toFixed(2) +'%';

            }
            this.performanceDetails={
                  metGoal:this.myTeamDetails.metGoals,
                  belowGoal:this.myTeamDetails.belowGoals,
                  totalAssociates:(parseInt(this.myTeamDetails.metGoals)+parseInt(this.myTeamDetails.belowGoals)).toString(),
                  plannedHrs:this.myTeamDetails.plannedHours,
                  actualHrs:this.myTeamDetails.actualHours,
                  variable:this.myTeamDetails.variable,
                  fixed:this.myTeamDetails.fixed,
                  }
                  this.doughnutChartData=[];
                  this.doughnutChartData.push(parseInt(this.myTeamDetails.metGoals));
                  this.doughnutChartData.push(parseInt(this.myTeamDetails.belowGoals));
    this.performanceDetails.progressWidth=this.getWidth(this.performanceDetails.plannedHrs,this.performanceDetails.actualHrs);
    this.performanceDetails.variableWdth=this.getWidth(this.performanceDetails.actualHrs,this.performanceDetails.variable);
    this.performanceDetails.fixedWdth=this.getWidth(this.performanceDetails.actualHrs,this.performanceDetails.fixed);
    this.performanceDetails.totalWidth=this.getWidth(this.performanceDetails.plannedHrs,this.performanceDetails.plannedHrs);
    if(this.performanceDetails.progressWidth>100)
    {
      var value=this.performanceDetails.progressWidth-100;
      this.performanceDetails.totalWidth=this.performanceDetails.totalWidth-value;
     
      this.performanceDetails.progressWidth=100;
    }
    this.performanceDetails.progressWidth=this.performanceDetails.progressWidth.toString()+'%';
    this.performanceDetails.variableWdth=this.performanceDetails.variableWdth.toString()+'%';
    this.performanceDetails.fixedWdth=this.performanceDetails.fixedWdth.toString()+'%';
    this.performanceDetails.totalWidth=this.performanceDetails.totalWidth.toString()+'%';
    var id1='plannedHrs',id2='actualHrs';
    this.showProgress=true;
    console.log('performance details' + JSON.stringify(this.performanceDetails));
  
    this.moveWidth(id1,this.performanceDetails.totalWidth);
    this.moveWidth(id2,this.performanceDetails.progressWidth);

          } else{this.showJoblist=false;this.showMyTeamPerf=false}
        },
        (err)=>{
          this.showLoader=false;
          this.showJoblist=false;
          console.log('Error Ocurred');
        })

    }
    
    viewDetails(jobdetail){
      var data={
        date:this.dateVal,
        shiftNbr:this.shiftNum,
        opsAreaDesc:jobdetail.opsAreaDesc,
        workArea:jobdetail.workAreaDesc,
        jobFunction :jobdetail.jobFunctionDesc,
        productivity:jobdetail.productivity,
        jobCode:jobdetail.supplyChainCd,
        Volume:jobdetail.volume,
        Hrs:jobdetail.totalHrs,
        goal:jobdetail.goal,
        goalCompletion:jobdetail.goalCompletion,
        prodFrmPrevDay:jobdetail.prodFrmPrevDay
      }
    //  console.log(JSON.stringify(jobdetail));
     this.router.navigate(['/view-details'],{ queryParams:data });
    }

    setSymbolSigns(data){
      if(data!==undefined)
      {
        if(data!==null)
      {
        var value=data;
      var value1=value.split('');
        if(value1[0]==='+'||value1[0]!=='+'||value1[0]!=='-')
        {
          return true;
        }else{
          return false;
        }
      }

      }
    }

    getClassByValue(data){
      if(data!==undefined)
      {
        var bol=this.setSymbolSigns(data);
      if(bol===true)
      {
        return 'green';
      }else{return 'red'}
      }
    }

    moveWidth(ids,wdth) {
      if(this.plannedHrs!==undefined ||this.actualHrs!==undefined)
      {
        //var elem = document.getElementById(ids)
      if(ids==='plannedHrs'){
        var elem=this.plannedHrs.nativeElement;
      }else if(ids==='actualHrs'){
        var elem=this.actualHrs.nativeElement;
      }
      //this.elementView.nativeElement.style.width
      var width = 1;
      var id = setInterval(frame,5);
      }
      function frame() {
        var wd=Math.round(parseInt(wdth));
    if (width >=wd) {
      clearInterval(id);
    } else {
      width++; 
      elem.style.width = width + '%'; 
    }
  }
  
}
    
}
