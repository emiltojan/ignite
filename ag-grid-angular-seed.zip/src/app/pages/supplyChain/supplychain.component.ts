import { Component, OnInit, ViewChild } from '@angular/core';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { SupplyChainService } from './../../services/supply-chain.service';
import { FilterByOPs, FilterByJob, FilterBySCC, FilterByFacility } from '../../components/filter/filter.component';
import { Router } from '@angular/router';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { GoalRenderer } from './ag-grid-renderer/goal-renderer';
import { SwitchRenderer} from './ag-grid-renderer/switch-renderer';
import {GetExceptionsService} from './../../services/exception.service';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'app-supplyChain',
  templateUrl: './supplychain.component.html',
  styleUrls: ['./supplychain.component.css'],
  providers: [SupplyChainService, NavbarComponent,GetExceptionsService]
})
export class SupplyChainComponent implements OnInit {
  supplyChainCode: any[] = [];
  selectedDetails: any[] = [];
  userid: string;
  loading:boolean = true;
  showLoader:boolean=false;
  rowData:any[];
  columnDefs:any[]=[];
  code:String;
  gridOptions={};
  private context;
  private frameworkComponents;
  private icons;
  private gridApi;
  private gridColumnApi;
  private paginationPageSize;
  public dummyData: Array<any>;
  public exportOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: false,
    headers: [],
    showTitle: false,
    useBom: true
  };
  headers_MX :any[]=['Operational Area', 'Work Area', 'JOb Function', 'Job Code', 'Goal','Active Indicator'];
  headers_CN :any[]=['Facility','Operational Area', 'Work Area', 'JOb Function', 'Job Code', 'Goal','Active Indicator'];
pagesList:any[] = ['10','25','50','100'];//Page Count
  constructor(public service: SupplyChainService, private router: Router, private navbar: NavbarComponent,private translate: TranslateService) {

this.icons = { filter:'<i class="fa fa-filter" style="font-size:18px"/>', menu:'<i style="display:none"/>'};
this.columnDefs = [];
this.gridOptions ={
paginationPageSize :parseInt(this.pagesList[0]),
columnDefs: this.columnDefs,
suppressCellSelection:true
};
  this.context = { componentParent: this };
  this.frameworkComponents = {
      goalRenderer: GoalRenderer,
      switchRenderer:SwitchRenderer

    };



    if (sessionStorage.getItem('loggedInUser')) {
      navbar.loggedIn = true;
    }
    else {
      navbar.loggedIn = false;
      this.router.navigate(['/login']);
    }
  }


 onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    params.api.sizeColumnsToFit();
    params.api.paginationGoToPage();
  }

  ngOnInit() {
  
    this.search();
    this. generateTranslation();
     this.rowData = this.supplyChainCode;
  }

  exportData() {
    var exportData: any[] =[];
   this.exportOptions.headers = [] ;
      if (sessionStorage.getItem('loggedinDomain') === 'MX') {
        this.exportOptions.headers.push(this.headers_MX);
      } else {
        this.exportOptions.headers.push(this.headers_CN);
      }  
    for (let j = 0; j < this.supplyChainCode.length; j++) {   
        if (sessionStorage.getItem('loggedinDomain') === 'MX') {
      exportData[j] = {
        "operationalAreaDesc" : this.supplyChainCode[j].operationalAreaDesc,
      "workAreaDesc" :  this.supplyChainCode[j].workAreaDesc,
      "jobFunctionDesc" : this.supplyChainCode[j].jobFunctionDesc,
      "supplyChainCd" : this.supplyChainCode[j].supplyChainCd,
      "productivityGoal"  : this.supplyChainCode[j].productivityGoal +" "+ this.supplyChainCode[j].metricTypeDesc ,
      "activeInd" : this.supplyChainCode[j].activeInd                    
    };
        } else {
          
           exportData[j] = {
             "Facility ID" : this.supplyChainCode[j].facilityId,
        "operationalAreaDesc" : this.supplyChainCode[j].operationalAreaDesc,
      "workAreaDesc" :  this.supplyChainCode[j].workAreaDesc,
      "jobFunctionDesc" : this.supplyChainCode[j].jobFunctionDesc,
      "supplyChainCd" : this.supplyChainCode[j].supplyChainCd,
      "productivityGoal"  : this.supplyChainCode[j].productivityGoal +" "+ this.supplyChainCode[j].metricTypeDesc ,
      "activeInd" : this.supplyChainCode[j].activeInd                       
    };
        }
    
  }
    console.log('exported data', exportData);
    new Angular2Csv(exportData, 'supplyChainData', this.exportOptions);
  }


  onSelect(data, value) {
    if (data.checkBoxValue) {
      data.activeInd = "Y";
    } else {
      data.activeInd = "N";
    }
    data.uomCode = data.prodMetricCode;
    console.log(data);
    this.service.saveSupplyChainCode(data)
      .subscribe((res:any) => {
        console.log(res);
         
      },(err)=>{
        console.error('failed to retrieve supplychain data');
      });
      
  }
 @ViewChild('pagesize') pagesize;

  onBlurGoal(data) { 
    console.log("onBlurGoal", data);
    this.service.saveSupplyChainGoal(data)
      .subscribe((res:any) => {
        console.log(res);
      },(err)=>{
        console.error('failed to retrieve supplychain data');
      });
      
  }

  onKeyPressNumber(event) { 
    return event.charCode >=48 && event.charCode <= 57;
  }
  onPageSizeChanged() {
    this.gridApi.paginationSetPageSize(Number(this.pagesize.nativeElement.value));
  }

   generateTranslation() {

    this.translate.get('SupplyChainCodeScreen.Headers')
      .subscribe((res) => {
        let parseData = this.parseData(res);
        this.columnDefs = parseData.columnDefs;
        if (sessionStorage.getItem('loggedinDomain') === 'MX') {
          this.columnDefs.splice(0,1);
        }
      },
       err => {
          console.log("Unable to retrive TPR Headers");
        });
      
  }
parseData(data) {

    let parseData = {
     columnDefs :[
  {headerName: "", field: "facilityId",width:60,minWidth: 100, cellStyle: {border:'0px' }},
  {headerName:"",field:'operationalAreaDesc',width:60,cellStyle: {border:'0px' }},
  {headerName:"",field:'workAreaDesc',width:70,cellStyle: {border:'0px' }},
  {headerName:"",field:'jobFunctionDesc',width:90,cellStyle: {border:'0px' }},
  {headerName:"",field:'supplyChainCd',width:60,cellStyle: {border:'0px' }},
  {headerName:"",field:'productivityGoal',cellRenderer: "goalRenderer",width:65, colId: "goal", suppressFilter:true,cellStyle: {border:'0px' }},
  // {headerName:'',field:'goal',width : 25,suppressFilter:true},
  {headerName:"",field:'activeInd',cellRenderer: "switchRenderer", colId: "switch",suppressFilter:true,width:60,cellStyle: {border:'0px' }}
], 
    }

    parseData.columnDefs[0].headerName = data.Facility;
    parseData.columnDefs[1].headerName = data.OperationalArea;
    parseData.columnDefs[2].headerName = data.WorkArea;
    parseData.columnDefs[3].headerName = data.JobFunction;
    parseData.columnDefs[4].headerName = data.SCC;
    parseData.columnDefs[5].headerName = data.Goal;
    parseData.columnDefs[6].headerName = data.Enable_Disable;

    
    return parseData;
  }

  search() {
    this.showLoader=true;
    this.service.getSupplyChainCode()
      .subscribe((res:any) => {
        console.log(res);
        if(res!==null)
        {
          if (res.supplyChainCode.length) {
          this.supplyChainCode = res.supplyChainCode;
        } else {
          this.supplyChainCode = [res.supplyChainCode];
        }
        for (let j = 0; j < this.supplyChainCode.length; j++) {
          if (this.supplyChainCode[j].activeInd == "Y") {
            this.supplyChainCode[j].checkBoxValue = true;
          } else {
            this.supplyChainCode[j].checkBoxValue = false;
          }
        }
        console.log(res, 'supplyChainData');
        this.showLoader=false;
        this.loading = false;
        }
        else{
          this.showLoader=false;
        }
         
      },(err)=>{ 
        this.showLoader=false;
         console.error('failed to retrieve supplychain data');
      })
  }

}
