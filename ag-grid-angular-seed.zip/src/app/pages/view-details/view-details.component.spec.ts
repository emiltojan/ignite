import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDetailsComponent } from './view-details.component';
import { Component, OnInit,ViewChild} from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import {DashboardComponent} from './../dashboard/dashboard.component';
import {FormControl,Validators} from '@angular/forms';
import { AssignShiftService } from './../../services/assign-shift.service';
import {GridOptions} from 'ag-grid/main';
import { ViewDetailsService } from './../../services/viewDetails.service';
import {Http,HttpModule} from '@angular/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";
import {MatMenuModule} from '@angular/material/menu';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";


describe('ViewDetailsComponent', () => {
  let component: ViewDetailsComponent;
  let fixture: ComponentFixture<ViewDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewDetailsComponent ],
      schemas: [NO_ERRORS_SCHEMA],
       imports:[ 
       MatMenuModule,
       HttpModule,
       HttpClientModule, 
       HttpClientTestingModule, 
       TranslateModule,
      RouterTestingModule],
     providers:[HttpClient,HttpClientModule,AssignShiftService,ViewDetailsService ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewDetailsComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    fixture.detectChanges();
  });

  it('should be  created', () => {
    expect(component).toBeTruthy();
  });

  it('should call getViewDetails method ',function(){
spyOn(component,'getViewDetails');
    component.getViewDetails();
expect(component.getViewDetails).toHaveBeenCalled();
  });

  it('should call getGridData method ',function(){
spyOn(component,'getGridData');
    component.getGridData();
expect(component.getGridData).toHaveBeenCalled();
  });
});
