import { Component, OnInit,ViewChild} from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import {DashboardComponent} from './../dashboard/dashboard.component';
import {FormControl,Validators} from '@angular/forms';
import { AssignShiftService } from './../../services/assign-shift.service';
import {GridOptions} from 'ag-grid/main';
import {TranslateService} from '@ngx-translate/core';
import { ViewDetailsService } from './../../services/viewDetails.service';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css'],
  providers: [ViewDetailsService]
})
export class ViewDetailsComponent implements OnInit {
shiftNbr:any;
date : any;
viewExceptionDetails:any[]=[];
icons:Object;
private gridApi;
 private gridColumnApi;
sub:any;
page:any;
jobdetails:any;
goalPercentage:any;
AllShifts:any;
ShiftList: any[] = [];
opsAreaDesc:any;
workArea:any;
jobFunction:any;
goal:any;
Productivity:any;
jobCode:any;
Volume:any;
Hrs:any;
toGoal :any;
rowData:any[]=[];
  columnDefs:any[]=[];
  gridOptions:GridOptions;
  productivityColor :any;
  Difference:any;
  arrowtype :any;
private paginationPageSize;
pagesList:any[] = ['10','25','50','100'];//Page Count
  constructor( private route: ActivatedRoute,private router: Router,public viewDetailsService:ViewDetailsService,private translate: TranslateService) {


   }

getViewDetails() {
 
 this.sub = this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.page = params;
        this.date=new FormControl(new Date (this.page.date));
       // this.jobdetails=this.page.opsAreaDesc;
       this.shiftNbr=this.page.shiftNbr==='0'?'All shift':this.page.shiftNbr;
       this.opsAreaDesc=this.page.opsAreaDesc;
       this.goal=this.page.goal;
       this.Hrs=this.page.Hrs;
       this.workArea=this.page.workArea;
       this.jobFunction=this.page.jobFunction;
       this.Productivity=this.page.productivity;
       this.jobCode=this.page.jobCode;
       this.Volume=this.page.Volume;
       this.goalPercentage= this.page.goalCompletion;//Math.round(this.Volume/this.goal)*100;
       this.Difference=this.page.prodFrmPrevDay;//Math.round(this.Productivity - this.goal);
       this.productivityColor = (this.Productivity - this.goal)> 0 ? "#81c74c" : "#e93221";
       this.arrowtype =(this.Productivity - this.goal)> 0 ? "arrow_upward" : "arrow_downward";
        console.log(this.page);
      });
 var data = {
   supplyChainCd :this.jobCode,
   shiftNbr : this.shiftNbr==='All shift'?'0':this.shiftNbr,
   prodDate : this.date
 }
       this.viewDetailsService.ViewDetails(data)
      .then((overAllData:any)=>{
        
          this.viewExceptionDetails=overAllData.associateProdList;
        })
             .catch(() => {
        console.error('Error Ocurred while fetching View Details List');
      });
}

getGridData(){
 this.gridOptions = <GridOptions>{};
    this.paginationPageSize = 10;
        this.icons = { checkboxChecked:'<i style="color:rgb(0, 125, 198);font-size:18px"  class="fa fa-check"/>',
filter:'<i class="fa fa-filter" style="font-size:18px"/>',
 menu:'<i style="display:none"/>'
              }
  }

@ViewChild('pagesize') pagesize;

  onPageSizeChanged() {
    this.gridApi.paginationSetPageSize(Number(this.pagesize.nativeElement.value));
}

 onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    params.api.sizeColumnsToFit();
    params.api.paginationGoToPage();
  }
 generateTranslation() {

    this.translate.get('ViewDetails')
      .subscribe((res) => {
        let parseData = this.parseData(res);
        this.columnDefs = parseData.columnDefs;
    
      },
       err => {
          console.log("Unable to retrive View Details Headers");
        });
      
  }

    parseData(data) {

    let parseData = {
     columnDefs :[
   {headerName:"",headerCheckboxSelection: true,width:80, suppressFilter:true,checkboxSelection: true,icons: { checkboxChecked:'<i style="color:rgb(0, 125, 198);font-size:18px"  class="fa fa-check-square"/>'} },
            {headerName: "", field: "assocName",width:170,cellStyle: {border:'0px' }},
            {headerName: "", field: "associateNumber",width:170,cellStyle: {border:'0px' }},
            {headerName: "", field: "volume",width:170,cellStyle: {border:'0px' }},
            {headerName: "", field: "hours",width:170,cellStyle: {border:'0px' }},
            {headerName: "", field: "goal",width:170,cellStyle: {border:'0px' }},
            {headerName: "", field: "plannedhours",width:150,cellStyle: {border:'0px' }},
            {headerName: "", field: "productivity",width:150,cellStyle: {border:'0px' }},
            {headerName: "", field: "goalCompletion",width:150,cellStyle: {border:'0px' }}
], 
    }

    parseData.columnDefs[1].headerName = data.Associate_Name;
    parseData.columnDefs[2].headerName = data.Associate_Number;
    parseData.columnDefs[3].headerName = data.Volume;
    parseData.columnDefs[4].headerName = data.Hours;
    parseData.columnDefs[5].headerName = data.Goal;
    parseData.columnDefs[6].headerName = data.Planned_Hrs;
    parseData.columnDefs[7].headerName = data.Productivity;
    parseData.columnDefs[8].headerName = data.Goal_Completion;
    return parseData;
  }

  ngOnInit() {
//this.date=new FormControl(this.DashboardComponentChild.dummy);

this.getViewDetails();
this.getGridData();
this.generateTranslation();
}
}

