import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { NoopAnimationsModule  } from '@angular/platform-browser/animations';
import { MatFormFieldModule, MatInputModule, MatCardModule, MatButtonModule, MatSelectModule} from '@angular/material';
import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";
import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';
import { MyDatePickerModule } from 'mydatepicker';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material';
import { AppComponent } from './app.component';
import{TokenInterceptor} from './app.interceptor';
import { DoughnutChartComponent, PieChartComponent, BarChartComponent } from 'angular-d3-charts'; 

// common component
import { AddAssociateComponent } from './components/add-associate/add-associate.component';
import { AssignShiftComponent } from './components/assign-shift/assign-shift.component';
import{TimeSheetEditOptionsComponent} from './components/time-sheet-edit-options/time-sheet-edit-options.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import {MatMenuModule} from '@angular/material/menu';

import { TprsetupComponent } from './pages/tprsetup/tprsetup.component';
import { TimesheetComponent } from './pages/timesheet/timesheet.component';
import { SupplyChainComponent } from './pages/supplyChain/supplychain.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ProductivityComponent } from './pages/productivity/productivity.component';
import { LoginComponent } from './pages/login/login.component';
import { ModalModule } from 'ngx-modialog';
import { BootstrapModalModule } from 'ngx-modialog/plugins/bootstrap';
import {AgGridModule} from 'ag-grid-angular/main';
import {EditRenderer} from './pages/timesheet/ad-grid-renderer/edit-renderer';
import { GoalRenderer } from './pages/supplyChain/ag-grid-renderer/goal-renderer';
import { SwitchRenderer } from './pages/supplyChain/ag-grid-renderer/switch-renderer';
import {VolumeRenderer} from  './pages/productivity/ag-grid-renderer/volume-renderer';
import {UnitsRenderer} from './pages/productivity/ag-grid-renderer/units-renderer';
import {PercentageRenderer} from './pages/productivity/ag-grid-renderer/percentage-renderer';
import { AppCommonServices } from './services/app-common.services';
import {MatSidenavModule} from '@angular/material/sidenav';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
import {MatExpansionModule} from '@angular/material/expansion';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import {MatToolbarModule} from '@angular/material/toolbar';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatRadioModule} from '@angular/material/radio';
import { ChartsModule } from 'ng2-charts';
import { ViewDetailsComponent } from './pages/view-details/view-details.component';
// AoT requires an exported function for factories
export function HttpLoaderFactory(httpClient: HttpClient) {
 return new TranslateHttpLoader(httpClient, "assets/i18n/", ".txt"); // Local
  // return new TranslateHttpLoader(httpClient, "/tpr/assets/i18n/", ".txt"); // Production
}

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    TimesheetComponent,
    SupplyChainComponent,
    TprsetupComponent,
    ProductivityComponent,
    LoginComponent,
    AddAssociateComponent,
    TimeSheetEditOptionsComponent,
    AssignShiftComponent,
    NavbarComponent,
    EditRenderer,
    GoalRenderer,
    SwitchRenderer,
    VolumeRenderer,
    UnitsRenderer,
    PercentageRenderer,
  DoughnutChartComponent,
  PieChartComponent,
   BarChartComponent,
   ViewDetailsComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    FormsModule,
    HttpModule,
    ComponentsModule,
    RouterModule,
    AppRoutingModule,
    ReactiveFormsModule,
    NoopAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    MatButtonModule,
    MatSelectModule,
    ModalModule.forRoot(),
    BootstrapModalModule,    
    HttpClientModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatToolbarModule,
    BrowserAnimationsModule,
    MatNativeDateModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    AgGridModule.withComponents([EditRenderer, 
    GoalRenderer,
    SwitchRenderer,
    VolumeRenderer,
    UnitsRenderer,
    PercentageRenderer]),
    AngularFontAwesomeModule,
    MyDatePickerModule,
    MatSidenavModule,
    MatExpansionModule,
    MatRadioModule,
    ChartsModule,
    MatDatepickerModule,
    MatMenuModule
  ],
  providers: [{
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    },AppCommonServices
    ],
  bootstrap: [AppComponent]
})
export class AppModule { }
