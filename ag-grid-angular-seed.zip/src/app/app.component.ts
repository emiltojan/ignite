import { Component, OnInit } from '@angular/core';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpEvent, HttpEventType } from '@angular/common/http';
import {TranslateService} from '@ngx-translate/core';
import { Router, NavigationEnd } from '@angular/router';
// import { DataService } from './services.data.service';

declare const $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[TranslateService]
})
export class AppComponent implements OnInit {
public isOpened :any;
private currentLoc = '';
loggedIn = false;
  constructor(public location: Location,private translate:TranslateService,private router: Router) {
    this.isOpened=false;
    router.events.subscribe((event) => {
			if (event instanceof NavigationEnd) {
				this.currentLoc = event.url;
				console.log(sessionStorage.getItem('loggedInUser'));
				if (sessionStorage.getItem('loggedInUser')) {
					this.loggedIn = true;
          translate.addLangs(["en", "ch"]);
		      translate.setDefaultLang(sessionStorage.getItem('loggedInLanguage'));
          const browserLang = translate.getBrowserLang();
        //  translate.use(browserLang.match(/en|ch/) ? browserLang : 'en');
				}
				else {
					this.loggedIn = false;
					this.router.navigate(['/login']);
				}

			}
		});
   }

  ngOnInit() {
    // $.material.options.autofill = true;
    // $.material.init();
  }

  enableNav(value)
  {
    this.isOpened = value;

    console.log(value);
  }

  isMaps(path) {
    var titlee = this.location.prepareExternalUrl(this.location.path());
    titlee = titlee.slice(1);
    if (path == titlee) {
      return false;
    }
    else {
      return true;
    }
  }
}
