import {Component, OnDestroy} from "@angular/core";
import {ICellRendererAngularComp} from "ag-grid-angular";



@Component({
    selector: 'units-renderer',
    template: `{{params.data.volumePerHour +' '+ params.data.UOMDescription}}`,
    providers:[]      
})
export class UnitsRenderer implements ICellRendererAngularComp, OnDestroy {

    private params: any;

    constructor()
    {
        
    }

    agInit(params: any): void {
        this.params = params;
    }



    ngOnDestroy() {
        console.log(`Destroying units-renderer`);
    }

    refresh(): boolean {
        return false;
    }



}