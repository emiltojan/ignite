import { Component, OnInit, ViewChild ,ElementRef } from '@angular/core';
import {IMyDpOptions,IMyDate, IMyDateModel} from 'mydatepicker';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { ProductivityService } from './../../services/productivity.service';
import { ShiftSetupService } from './../../services/shift-setup.service';
import { AssignShiftService } from './../../services/assign-shift.service';
import { FilterByOpsAreaDesc, FilterByJob, FilterBySCC, FilterByAssocName } from '../../components/filter/filter.component';
import { Router } from '@angular/router';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import {VolumeRenderer} from './ag-grid-renderer/volume-renderer';
import {UnitsRenderer} from './ag-grid-renderer/units-renderer';
import {PercentageRenderer} from './ag-grid-renderer/percentage-renderer';
import {GetExceptionsService} from './../../services/exception.service';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'app-productivity',
  templateUrl: './productivity.component.html',
  styleUrls: ['./productivity.component.css'],
  providers: [ProductivityService, ShiftSetupService, AssignShiftService, NavbarComponent,GetExceptionsService]
})
export class ProductivityComponent implements OnInit {
  AssociateProductivity: any[] = [];
  paramDate:String;
  TeamProductivity: any[] = [];
  ShiftList: any[] = [];
  FacilityList: any[] = [];
  userid: string;
  
  shiftNbr: string ="";
  private icons;
  facilityId: string = "";
  loading:boolean = false;
  submitted:boolean = false;
  showVolumeUpdateMessage: boolean = false;
  tab:string = "associate";
  private shiftDate: IMyDate = {year:0,month:0,day:0};
  private myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'mm/dd/yyyy',
        showTodayBtn:false,
        showClearDateBtn:false,
        markCurrentDay:true,
        maxYear:new Date().getFullYear(),
    };
private placeholder: string = 'mm/dd/yyyy';
private singleColumnDefs:any[];
private singleContext:Object;
private singleFrameworkComponents:Object;
private associatepaginationPageSize;
private teampaginationPageSize;
private teamColumnDefs:any[];
private teamContext:Object;
private teamFrameworkComponents:Object;

private singleGridApi;
private singleGridColumnApi;
private teamGridApi;
private teamGridColumnApi;


onSingleGridReady(params)
{
this.singleGridApi=params.api;
this.singleGridColumnApi=params.columnApi;

}

onTeamGridReady(params)
{
this.teamGridApi=params.api;
this.teamGridColumnApi=params.columnApi;

}
 onDateChanged(event: IMyDateModel) {
        // Update value of selDate variable
        console.log(event.date);
        this.shiftDate = event.date;
    }
 clearDate() {
        this.shiftDate ={year:0,month:0,day:0};
    }

  public dummyData: Array<any>;
  public exportOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: false,
    headers: (['Operational Area', 'Work area', 'job function', 'SCC', 'Name', 'Volume', 'Time', 'Volume', 'UOM', 'Goal']),
    showTitle: false,
    useBom: true
  };

  constructor(public service: ProductivityService,
    public assignShitService: AssignShiftService,
    public shiftService: ShiftSetupService,
    private router: Router, private navbar: NavbarComponent, private translate: TranslateService) {
       var yesterday = new Date(Date.now()- 864e5);
this.shiftDate ={ 
      year: yesterday.getFullYear(),
      month: (yesterday.getMonth() + 1),
      day: (yesterday.getDate())};

this.icons = { filter:'<i class="fa fa-filter" style="font-size:18px"/>', menu:'<i style="display:none"/>'};


this.associatepaginationPageSize = 10;
this.teampaginationPageSize=10;




  this.singleContext = { componentParent: this };
  this.singleFrameworkComponents = {
      volumeRenderer:VolumeRenderer,
      unitsRenderer:UnitsRenderer,
      percentageRenderer:PercentageRenderer
    };


    if (sessionStorage.getItem('loggedInUser')) {
      navbar.loggedIn = true;
      //appComp.userName = utilitysvc.getsessionStorage('loggedInUser').valueOf();
      //this.userid = sessionStorage.getItem('loggedInUserId').valueOf();
    }
    else {
      navbar.loggedIn = false;
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    var date = new Date();
    let str = date.getDate();
    console.log(str.toString().length);
    this.generateAssocTranslation();
    this.generateTeamTranslation();
//     if (str.toString().length == 1) {
//       this.shiftDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-0' + date.getDate();
//     } else {
//       this.shiftDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
//     }
// if(sessionStorage.getItem('ProductivityDate')){
//        this.shiftDate = sessionStorage.getItem('ProductivityDate')
//      }
    this.assignShitService.getShiftsList()
      .subscribe((ShiftDetails:any) => {
        if(ShiftDetails!==null)
        {
          if(ShiftDetails!==undefined &&ShiftDetails.dcShift!==undefined)
          {
            this.ShiftList = ShiftDetails.dcShift;
          }
        }
        
      },(err)=>{
        console.error('failed to retrieve shift details');
      });
      

    this.shiftService.getFacility()
      .subscribe((FacilityData:any) => {
        if(FacilityData!==null)
        {
          if(FacilityData!==undefined &&FacilityData.FacilityTO!==undefined){
            this.FacilityList = FacilityData.FacilityTO;
          }
        }
        
      },(err)=>{
        console.error('failed to retrieve associate data');
      });
      

    //this.searchAssociateProd();
    
  }

  exportData() {
    var exportData: any[] = [];

    if(this.tab=="associate"){
       for (let j = 0; j < this.AssociateProductivity.length; j++) {
      exportData[j] = {
        "operationalAreaDesc": this.AssociateProductivity[j].opsAreaDesc,
        "workAreaDesc": this.AssociateProductivity[j].workAreaDesc,
        "jobFunctionDesc": this.AssociateProductivity[j].jobFunctionDesc,
        "supplyChainCd": this.AssociateProductivity[j].supplyChainCd,
        "assocName": this.AssociateProductivity[j].assocName,
         "volume": this.AssociateProductivity[j].volume,
        "totalHours": this.AssociateProductivity[j].totalHrs,
        "volumePerHour": this.AssociateProductivity[j].volumePerHour,
        "uom": this.AssociateProductivity[j].uom,
        "goal": this.AssociateProductivity[j].goal
      };
    }
    new Angular2Csv(exportData, 'AssociateProductivity', this.exportOptions);

    }else if(this.tab=="team"){
       for (let j = 0; j < this.TeamProductivity.length; j++) {
      exportData[j] = {
        "operationalAreaDesc": this.TeamProductivity[j].opsAreaDesc,
        "workAreaDesc": this.TeamProductivity[j].workAreaDesc,
        "jobFunctionDesc": this.TeamProductivity[j].jobFunctionDesc,
        "supplyChainCd": this.TeamProductivity[j].supplyChainCd,
        "assocName": this.TeamProductivity[j].assocName,
         "volume": this.TeamProductivity[j].volume,
        "totalHours": this.TeamProductivity[j].totalHrs,
        "volumePerHour": this.TeamProductivity[j].volumePerHour        
      };
    }
    new Angular2Csv(exportData, 'TeamProductivity', this.exportOptions);
    }
   
  }

  activeTab(tab){
    this.tab= tab;
  }

@ViewChild('associatepagesize') associatepagesize;
@ViewChild('teampagesize') teampagesize;

  onassociatePageSizeChanged() {
    this.singleGridApi.paginationSetPageSize(Number(this.associatepagesize.nativeElement.value));
  }
  onteamPageSizeChanged() {
    this.teamGridApi.paginationSetPageSize(Number(this.teampagesize.nativeElement.value));
  }

   generateAssocTranslation() {

    this.translate.get('ProductivityScreen.Headers')
      .subscribe((res) => {
        let parseData1 = this.parseData(res);
        this.singleColumnDefs = parseData1.singleColumnDefs;
      },
       err => {
          console.log("Unable to retrive Productivity Headers");
        });
      
  }

   generateTeamTranslation() {

    this.translate.get('ProductivityScreen.Headers')
      .subscribe((res) => {
        let parseData2 = this.parseData(res);
        this.teamColumnDefs = parseData2.teamColumnDefs;
      },
       err => {
          console.log("Unable to retrive Productivity Headers");
        });
      
  }
parseData(data) {

    let parseData = {
     singleColumnDefs :[
  {headerName:"",field:'opsAreaDesc',width:150,cellStyle: {border:'0px' }},
  {headerName:"",field:'workAreaDesc',width:150,cellStyle: {border:'0px' }},
  {headerName:"",field:'jobFunctionDesc',width:150,cellStyle: {border:'0px' }},
  {headerName:"",field:'supplyChainCd',width:150,cellStyle: {border:'0px' }},
  {headerName:"",field:'assocName',width:150,cellStyle: {border:'0px' }},
  {headerName:"",field:'volume',cellRenderer: "volumeRenderer",  colId: "volume",suppressFilter:true,width:150,cellStyle: {border:'0px' }},
  {headerName:"",field:'totalHrs',width:150,cellStyle: {border:'0px' }},
  {headerName:"",field:'volumePerHour',cellRenderer: "unitsRenderer", colId: "Productivity",width:150,cellStyle: {border:'0px' }},
  {headerName:"",field:'goal',width:150,cellStyle: {border:'0px' }},
  {headerName:"",cellRenderer: "percentageRenderer", colId: "percentage",suppressFilter:true,width:150,cellStyle: {border:'0px' }},
  {headerName:"",cellRenderer: "thumbsRenderer", colId: "thumbs",suppressFilter:true,width:150,cellStyle: {border:'0px' }}
], 
teamColumnDefs : [
  {headerName:"",field:'opsAreaDesc', width:200},
  {headerName:"",field:'workAreaDesc', width:150},
  {headerName:"",field:'jobFunctionDesc'},
  {headerName:"",field:'supplyChainCd',width:150},
  {headerName:"",field:'volume'},
  {headerName:"",field:'totalHrs'},
  {headerName:"",field:'productivity',cellRenderer: "ProductivityRenderer", colId: "Productivity"}
]

    }

    parseData.singleColumnDefs[0].headerName = data.OperationalArea;
    parseData.singleColumnDefs[1].headerName = data.WorkArea;
    parseData.singleColumnDefs[2].headerName = data.JobFunction;
    parseData.singleColumnDefs[3].headerName = data.SCC;
    parseData.singleColumnDefs[4].headerName = data.Name;
    parseData.singleColumnDefs[5].headerName = data.Volume;
    parseData.singleColumnDefs[6].headerName = data.Time;
    parseData.singleColumnDefs[7].headerName = data.Productivity;
    parseData.singleColumnDefs[8].headerName = data.Goal;
    parseData.singleColumnDefs[9].headerName = data.Goalper;
  
console.log('parse==>',parseData.singleColumnDefs);
     parseData.teamColumnDefs[0].headerName = data.OperationalArea;
    parseData.teamColumnDefs[1].headerName = data.WorkArea;
    parseData.teamColumnDefs[2].headerName = data.JobFunction;
    parseData.teamColumnDefs[3].headerName = data.SCC;
    parseData.teamColumnDefs[4].headerName = data.Volume;
    parseData.teamColumnDefs[5].headerName = data.Time;
     parseData.teamColumnDefs[6].headerName = data.Productivity;

    
    return parseData;
  }
  
  searchAssociateProd() {
    this.loading = true; 
    this.submitted = false;
    this.AssociateProductivity = [];
    // var searchDate = this.shiftDate.replace(/-/g, "/");
    this.paramDate=this.shiftDate.year+'/'+this.shiftDate.month+'/'+this.shiftDate.day;
    var searchDate =this.paramDate;
    this.service.getAssociateProd(searchDate, this.shiftNbr, this.facilityId)
      .subscribe((AssociateData:any) => {
        if(AssociateData!==null){
          console.log(AssociateData);
         if (AssociateData.associateProductivity.length) {
          this.AssociateProductivity = AssociateData.associateProductivity;
        } else {
          this.AssociateProductivity = [AssociateData.associateProductivity];
        }        
        console.log(this.AssociateProductivity);
         this.searchTeamProd();
        }
      },(err)=>{
       this.searchTeamProd();
         this.AssociateProductivity =[];
        console.error('failed to retrieve Associate Productivity data');
      })
      
  }

  searchTeamProd() {
    this.loading = true; 
    this.submitted = false;

    this.TeamProductivity = [];
   this.paramDate=this.shiftDate.year+'/'+this.shiftDate.month+'/'+this.shiftDate.day;
    var searchDate =this.paramDate;
    this.service.getTeamProd(searchDate, this.shiftNbr, this.facilityId)
      .subscribe((TeamData:any) => {
        if(TeamData!==null)
        {
          if (TeamData.teamProductivity.length) {
          this.TeamProductivity = TeamData.teamProductivity;
        } else {
          this.TeamProductivity = [TeamData.teamProductivity];
        }
         this.loading = false; 
         this.submitted = true;
        }
      },(err)=>{
         this.loading = false; 
         this.submitted = true;
        console.error('failed to retrieve Team Productivity data');
      })
      
  }

  search() {
    this.searchAssociateProd();
    
  }

  onFocusVolume(){

    this.showVolumeUpdateMessage =false;
  }

  modifyAssociateVolume(data) {
    data["rptDate"] = this.shiftDate; 
    this.service.modifyVolume(data)
      .subscribe((res:any) => {
        if(res!==null)
        {
          console.log(res);
        this.showVolumeUpdateMessage = true;
        } 
      },(err)=>{
        console.error('failed to update volume');
      });
     
  }

  onKeyPressNumber(event) {
    return event.charCode >= 48 && event.charCode <= 57;
  }

}