import {Component, OnDestroy,ViewChild,Output, EventEmitter,Input} from "@angular/core";
import {ICellRendererAngularComp} from "ag-grid-angular";
import { TimeSheetEditOptionsComponent } from '../../../components/time-sheet-edit-options/time-sheet-edit-options.component';



@Component({
    selector: 'edit-render',
    template: `<i (click)="showEditOptions(params.data,params)" class="material-icons">border_color</i>
    <app-time-sheet-edit-options (userUpdated)="refreshGrid()"></app-time-sheet-edit-options>`,
    providers: []      
})
export class EditRenderer implements ICellRendererAngularComp, OnDestroy {

    private params: any;
     @ViewChild(TimeSheetEditOptionsComponent) TimeSheetEditOptionsChild: TimeSheetEditOptionsComponent;
  
showEditOptions(data) {
    this.TimeSheetEditOptionsChild.showModalBox(data);
  }
 constructor()
    {
        
    }

    agInit(params: any): void {
        this.params = params;
    }

    refreshGrid(){
        this.params.context.componentParent.search();
    }
    ngOnDestroy() {
        console.log(`Destroying SquareComponent`);
    }

    refresh(): boolean {
        return true;
    }


}