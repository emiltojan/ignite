import {MatMenuModule} from '@angular/material/menu';
import { Router } from '@angular/router';
import { async, ComponentFixture, TestBed,inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import {Http,HttpModule} from '@angular/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";
import { DashboardComponent } from './dashboard.component';
import { AssignShiftService } from './../../services/assign-shift.service';
import { DashboardService } from './../../services/dashboard.service';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
export function HttpLoaderFactory(httpClient: HttpClient) {
 //return new TranslateHttpLoader(httpClient, "assets/i18n/", ".txt"); // Local
   return new TranslateHttpLoader(httpClient, "/tpr/assets/i18n/", ".txt"); // Production
}

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  var foo,bar=null,date=null,shift=null, spy;
  beforeEach(async(() => {
    let routerStub = {
    navigate: jasmine.createSpy('navigate'),
  };
    TestBed.configureTestingModule({
      declarations: [ DashboardComponent ],
      schemas: [NO_ERRORS_SCHEMA],
       imports:[ 
       MatMenuModule,
       HttpModule,
       HttpClientModule, 
       HttpClientTestingModule, 
       TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
       }}),
      RouterTestingModule],
     providers:[HttpClient,HttpClientModule,AssignShiftService,DashboardService ]
     
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    fixture.detectChanges();
    
  });


  it('should be created', inject([HttpClientModule,HttpClientTestingModule], (service: DashboardComponent) => {
    expect(service).toBeTruthy();
  }));


  it('should call onDateChange method ',function()  {
  spyOn(component,"onDateChange");
  component.onDateChange(testData().date);
  expect(component.onDateChange).toHaveBeenCalledWith(testData().date);
  });

  it('should call ViewDetails method',function() {
spyOn(component,'viewDetails');
component.viewDetails(testData().jobDetails);
expect(component.viewDetails).toHaveBeenCalledWith(testData().jobDetails);
  });

  it('should call the callDashBoard method', function() {
    spyOn(component,'callDashBoard');
    component.callDashBoard(testData().date,testData().shiftNum);
expect(component.callDashBoard).toHaveBeenCalledWith(testData().date,testData().shiftNum);
  });

  it('should call onChange method ',function () {
    spyOn(component,'onChange');
    component.onChange(testData().shiftNum);
expect(component.onChange).toHaveBeenCalledWith(testData().shiftNum);
  });
});

function testData() {

 return { 
   jobDetails : {
  opsAreaDesc :'abc',
  workAreaDesc :'def',
  jobFunctionDesc :'ghi',
  productivity : 123,
  supplyChainCd :234,
  volume :10,
  totalHrs :3,
  goal :10,
  goalCompletion :5,
  prodFrmPrevDay :2

},
 date :'02/10/2018',
 shiftNum :2
 };

}

