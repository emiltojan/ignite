import {Component, OnDestroy} from "@angular/core";
import {ICellRendererAngularComp} from "ag-grid-angular";
import { SupplyChainService } from './../../../services/supply-chain.service';


@Component({
    selector: 'goal-renderer',
    template: ` 
                <div class="ag-header-cell" aria-hidden="true">
                <div class="ag-floating-filter-body" style="margin-top:-5px" aria-hidden="true">
                <div>
  <input type="text" class="ag-floating-filter-input"
                (keypress)="onKeyPressNumber($event)" [(ngModel)]="params.data.productivityGoal"
                (blur)="onBlurGoal(params.data)" style="width:50px"><span>{{params.data.metricTypeDesc}}</span>
           


                </div>
                </div>
                </div>`,
    providers: [SupplyChainService]      
})
export class GoalRenderer implements ICellRendererAngularComp, OnDestroy {

    private params: any;

    constructor(private service: SupplyChainService)
    {
        
    }

    agInit(params: any): void {
        this.params = params;
        console.log(this.params);
    }

    public valueSquared(): number {
        return this.params.value * this.params.value;
    }

    ngOnDestroy() {
        console.log(`Destroying SquareComponent`);
    }

    refresh(): boolean {
        return false;
    }

onKeyPressNumber(event) { 
    return event.charCode >=48 && event.charCode <= 57;
  }

onBlurGoal(data) { 
   if( this.params.value !== this.params.data.productivityGoal)
   {
         this.service.saveSupplyChainGoal(data)
      .subscribe((res) => {
        console.log(res);
      },(err)=>{
        console.error('failed to retrieve supplychain data');
      });
      
   }
 
  }
}