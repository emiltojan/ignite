import {Component, OnDestroy} from "@angular/core";
import {ICellRendererAngularComp} from "ag-grid-angular";
import { SupplyChainService } from './../../../services/supply-chain.service';


@Component({
    selector: 'switch-render',
 template: ` <mat-checkbox [(ngModel)]="params.data.checkBoxValue" (change)="onSelect(params.data,params.data.checkBoxValue)" color="primary"></mat-checkbox>`,
  
    providers: [SupplyChainService]      
})
export class SwitchRenderer implements ICellRendererAngularComp, OnDestroy {

    private params: any;

    constructor(private service: SupplyChainService)
    {
        
    }

    agInit(params: any): void {
        this.params = params;
        console.log(this.params);
    }

    public valueSquared(): number {
        return this.params.value * this.params.value;
    }

    ngOnDestroy() {
        console.log(`Destroying SquareComponent`);
    }

    refresh(): boolean {
        return false;
    }

    onSelect(data, value) {
    if (data.checkBoxValue) {
      data.activeInd = "Y";
    } else {
      data.activeInd = "N";
    }
    data.uomCode = data.prodMetricCode;
    console.log(data);
    this.service.saveSupplyChainCode(data)
      .subscribe((res) => {
        console.log(res);
         
      },(err)=> {
        console.error('failed to retrieve supplychain data');
      });
     
  }

}