import { BrowserModule } from '@angular/platform-browser';
import {MatMenuModule} from '@angular/material/menu';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import {Http,HttpModule} from '@angular/http';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";
import { RouterTestingModule } from '@angular/router/testing';
import { SupplyChainComponent } from './supplychain.component';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { async, ComponentFixture, TestBed,inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { AppCommonServices } from './../../services/app-common.services';
import { SupplyChainService } from './../../services/supply-chain.service';
import { GetExceptionsService } from './../../services/exception.service';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
export function HttpLoaderFactory(httpClient: HttpClient) {
 //return new TranslateHttpLoader(httpClient, "assets/i18n/", ".txt"); // Local
   return new TranslateHttpLoader(httpClient, "/tpr/assets/i18n/", ".txt"); // Production
}


describe('SupplyChainComponent', () => {
  let component: SupplyChainComponent;
  let fixture: ComponentFixture<SupplyChainComponent>;
let user={};
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupplyChainComponent ],
       schemas: [NO_ERRORS_SCHEMA],
        imports:[ 
       MatMenuModule,
       HttpModule,
       HttpClientModule, 
       HttpClientTestingModule, 
       TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
       }}),
      RouterTestingModule],
      providers:[ NavbarComponent,AppCommonServices,GetExceptionsService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupplyChainComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

   it('search is called onload', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'search');
    component.search();
    expect(component.search).toHaveBeenCalled();
  }));
   it('exportData is called', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'exportData');
    component.exportData();
    expect(component.exportData).toHaveBeenCalled();
  }));

  

});
