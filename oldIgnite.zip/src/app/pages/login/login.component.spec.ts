// import { BrowserModule } from '@angular/platform-browser';
// import { FormsModule}   from '@angular/forms';
// import {Http,HttpModule} from '@angular/http';
// import { NO_ERRORS_SCHEMA } from '@angular/core';
// import { RouterTestingModule } from '@angular/router/testing';
// import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { LoginComponent } from './login.component';
// import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
// import {TranslateHttpLoader} from "@ngx-translate/http-loader";

// describe('LoginComponent', () => {
//   let component: LoginComponent;
//   let fixture: ComponentFixture<LoginComponent>;
//   let modal;
//   beforeEach(async(() => {
//     modal = { openModal: jasmine.createSpy('openModal') }; //{ provide: Modal, useValue: modal }
//     TestBed.configureTestingModule({
//       declarations: [ LoginComponent ],
//        schemas: [NO_ERRORS_SCHEMA],
//       imports:[ 
//       BrowserModule,
//       FormsModule,
//       HttpModule,
//       HttpClientModule,  
//      RouterTestingModule],
//     providers:[HttpClient,HttpClientModule, ],
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(LoginComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
