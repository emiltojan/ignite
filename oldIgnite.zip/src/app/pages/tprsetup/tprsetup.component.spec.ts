import { BrowserModule } from '@angular/platform-browser';
import {MatMenuModule} from '@angular/material/menu';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import {Http,HttpModule} from '@angular/http';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";
import { RouterTestingModule } from '@angular/router/testing';
import { TprsetupComponent } from './tprsetup.component';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { AppComponent } from '../../app.component';
import { ShiftSetupService } from '../../services/shift-setup.service';
import { AssignShiftService } from '../../services/assign-shift.service';
import { async, ComponentFixture, TestBed,inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { AppCommonServices } from './../../services/app-common.services';
import { SupplyChainService } from './../../services/supply-chain.service';
import { GetExceptionsService } from './../../services/exception.service';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
export function HttpLoaderFactory(httpClient: HttpClient) {
 //return new TranslateHttpLoader(httpClient, "assets/i18n/", ".txt"); // Local
   return new TranslateHttpLoader(httpClient, "/tpr/assets/i18n/", ".txt"); // Production
}


describe('TprsetupComponent', () => {
  let component: TprsetupComponent;
  let fixture: ComponentFixture<TprsetupComponent>;
let user={};
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TprsetupComponent ],
       schemas: [NO_ERRORS_SCHEMA],
        imports:[ 
       MatMenuModule,
       HttpModule,
       HttpClientModule, 
       HttpClientTestingModule, 
       TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
       }}),
      RouterTestingModule],
      providers: [ShiftSetupService, AssignShiftService, AppComponent, NavbarComponent,GetExceptionsService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TprsetupComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  //  it('getDcshift is called onload', inject([HttpClientModule,HttpClientTestingModule], () => {
  //     spyOn(component,'getDcshift');
  //   component.getDcshift();
  //   expect(component.getDcshift).toHaveBeenCalled();
  // }));
   it('exportData is called', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'exportData');
    component.exportData();
    expect(component.exportData).toHaveBeenCalled();
  }));
  //getfacility getAssociate checkAll onPageSizeChanged
//  it('getfacility is called', inject([HttpClientModule,HttpClientTestingModule], () => {
//       spyOn(component,'getfacilityCall');
//     component.getfacilityCall();
//     expect(component.getfacilityCall).toHaveBeenCalled();
//   }));

   it('getAssociate is called', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'getAssociate');
    component.getAssociate();
    expect(component.getAssociate).toHaveBeenCalled();
  }));

  it('checkAll is called', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'checkAll');
    component.checkAll();
    expect(component.checkAll).toHaveBeenCalled();
  }));

   it('onPageSizeChanged is called', inject([HttpClientModule,HttpClientTestingModule], () => {
      spyOn(component,'onPageSizeChanged');
    component.onPageSizeChanged();
    expect(component.onPageSizeChanged).toHaveBeenCalled();
  }));
  

});

