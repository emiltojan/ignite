import { Component, OnInit, ElementRef,ViewChild, Output, EventEmitter} from '@angular/core';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { Router, NavigationEnd } from '@angular/router';
import {AppComponent} from './../../app.component';
import {TprsetupComponent} from './../../pages/tprsetup/tprsetup.component';
import {TranslateService} from '@ngx-translate/core';
import {GetExceptionsService} from './../../services/exception.service';
import { AfterViewInit } from '@angular/core';
import {MatMenuModule} from '@angular/material/menu';
@Component({
	selector: 'app-navbar',
	templateUrl: './navbar.component.html',
	styleUrls: ['./navbar.component.css'],
  providers: [GetExceptionsService]
})
export class NavbarComponent implements OnInit{
public isOpened :any;
private currentLoc = '';
menuList:any[] =[];
notificationCount:number ;
loggedIn = false;
fullname :any;
displayname :any;
names :any=[];

  constructor(public location: Location,private translate:TranslateService,private router: Router,public getExceptionService: GetExceptionsService ) {
    this.isOpened=false;
    router.events.subscribe((event) => {
			if (event instanceof NavigationEnd) {
				this.currentLoc = event.url;
				//console.log(sessionStorage.getItem('loggedInUser').valueOf());
				if (sessionStorage.getItem('loggedInUser')) {
					this.loggedIn = true;
					translate.setDefaultLang(sessionStorage.getItem('loggedInLanguage').valueOf());
				}
				else {
					this.loggedIn = false;
					this.router.navigate(['/login']);
				}

			}
		});
 //   this.fullname = sessionStorage.getItem('loggedInUser');
 this.fullname="Sysadmin"
   // this.names= sessionStorage.getItem('loggedInUser').toString().split(' ');
   // this.displayname = this.names[0].toString().substring(0,1)+this.names[1].toString().substring(0,1);
   this.displayname="SA";
    this.getExceptionService.getExceptions()
      .then((menuDetails) => {
        this.menuList=menuDetails.associateDetails;
        console.log("Length is " + this.menuList.length);
       this.notificationCount = this.menuList.length;
      })
      .catch(() => {
        console.error('Error Ocurred while fetching Exception List');
      });
   
   }

ngAfterViewInit(){

}
  ngOnInit() {
   
    
  }


  enableNav(value)
  {
    this.isOpened = value;

    console.log(value);
  }

  isMaps(path) {
    var titlee = this.location.prepareExternalUrl(this.location.path());
    titlee = titlee.slice(1);
    if (path == titlee) {
      return false;
    }
    else {
      return true;
    }
  }
}
