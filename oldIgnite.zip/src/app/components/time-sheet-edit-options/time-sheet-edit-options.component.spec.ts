// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { TimeSheetEditOptionsComponent } from './time-sheet-edit-options.component';

// describe('TimeSheetEditOptionsComponent', () => {
//   let component: TimeSheetEditOptionsComponent;
//   let fixture: ComponentFixture<TimeSheetEditOptionsComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ TimeSheetEditOptionsComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(TimeSheetEditOptionsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should call showModalBox method ',function () {
//     spyOn(component,'showModalBox');
//     component.showModalBox(testData().data);
// expect(component.showModalBox).toHaveBeenCalled();
//   });


// });

// function testData(){
//     return {
//         data :{
//             attendance :'dummy',
//             supplyChainCd :'123',
//             dfltFacilityAreaCode :'123'

//         }
//     }
// }


import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { AddAssociateService } from './../../services/add-associate.service';
import { Overlay } from 'ngx-modialog';
import { Modal } from 'ngx-modialog/plugins/bootstrap';

import {TranslateService} from '@ngx-translate/core';
import {MatMenuModule} from '@angular/material/menu';
import { Router } from '@angular/router';

import { MockBackend, MockConnection } from '@angular/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import {Http,HttpModule} from '@angular/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";

import { AppComponent } from '../../app.component';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { TimeSheetEditOptionsComponent } from './time-sheet-edit-options.component';
import { TimesheetService } from './../../services/timesheet.service';
import { ShiftSetupService } from './../../services/shift-setup.service';
import { AppCommonServices } from './../../services/app-common.services';
import {GetExceptionsService} from './../../services/exception.service';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
export function HttpLoaderFactory(httpClient: HttpClient) {
 //return new TranslateHttpLoader(httpClient, "assets/i18n/", ".txt"); // Local
   return new TranslateHttpLoader(httpClient, "/tpr/assets/i18n/", ".txt"); // Production
}

describe('TimeSheetEditOptionsComponent', () => {
  let component: TimeSheetEditOptionsComponent;
  let fixture: ComponentFixture<TimeSheetEditOptionsComponent>;
  let modal;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TimeSheetEditOptionsComponent ],
       imports:[ 
       BrowserModule,
       FormsModule,                              
       MatMenuModule,
       HttpModule,
       HttpClientModule, 
       HttpClientTestingModule, 
       TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
       }}),
      RouterTestingModule],
       providers:[TranslateService,ShiftSetupService,TimesheetService,{ provide: Modal, useValue: modal }]
    })
    .compileComponents();
    modal = { openModal: jasmine.createSpy('openModal') }
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeSheetEditOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

//   it('should call showModalBox method ',function () {
//     spyOn(component,'showModalBox');
//     component.showModalBox(testData().value,testData().timesheet);
// expect(component.showModalBox).toHaveBeenCalledWith(testData().value,testData().timesheet);
//   });



});

// function testData(){
//     return { 
//    value:true,
//    timesheet:true,
//    newAssociate :{
// value :{
//     obsoleteInd :'N',
//     dfltSettingsEffDate :'02/20/2018',
//     taAssociateId :'12345',
//     shiftStartTime:'8:00',
//     shiftDate :'02/20/2018',
//     supplyChainCd :'123',
//     dfltShiftNbr :2
// }
//    }
//    }
// }




