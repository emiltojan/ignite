import { Component, OnInit, ViewChild , Output, EventEmitter,Input} from '@angular/core';
import { NgForm } from '@angular/forms';
import { TimesheetService } from './../../services/timesheet.service';
import { ShiftSetupService } from './../../services/shift-setup.service';
import { uniqBy } from 'lodash';

@Component({
  selector: 'app-time-sheet-edit-options',
  templateUrl: './time-sheet-edit-options.component.html',
  styleUrls: ['./time-sheet-edit-options.component.css','./bootstrap-3.3.5-dist/css/bootstrap.css'],
  providers: [ ShiftSetupService,TimesheetService]
})
export class TimeSheetEditOptionsComponent implements OnInit {
  Assignshift: any[] = [];
  ShiftList: any[] = []
  ShiftData: any[];
 // FacilityList: any[] = [];
  StartTime: any;
  EndTime: any;
  BreakInTime: any;
  BreakOutTime: any;
  shiftDate: any;
  facilityId: any;
  splitArray: any[] = [];
  attendanceData: any[];
  showConfirmMsgModal :boolean = false;
  confirmMsg : string = "" ;
  addTimeArr:any=[];
  delTimeArr:any=[]; 
  num = 0;
  facilList:any;
  constructor(public timesheetService:TimesheetService,
  public shiftService: ShiftSetupService) { }
  private showModal;
 @ViewChild('shiftData')  private shiftData: NgForm;
  ngOnInit() {
   
      
  }
 @Output() userUpdated = new EventEmitter<any>();
  updateShift(shiftData: NgForm) {
    console.log("Shift data" + shiftData.value);
    console.log('this.ShiftData ', this.ShiftData);
    for (let j = 0; j < this.splitArray.length; j++) {
      if (this.splitArray[j].sccPrevious != "") {
        for (let x = 0; x < this.attendanceData.length; x++) {
          if (this.splitArray[j].sccPrevious == this.attendanceData[x].supplyChainCd) {
            if(this.splitArray[j].sccRowId == this.attendanceData[x].sccRowId)
            {
              this.attendanceData[x].supplyChainCd = this.splitArray[j].scc;
              this.attendanceData[x].clockTime = this.splitArray[j].splitStartTime;
            }
        
          }
        }
      } else if ((this.splitArray[j].sccPrevious == "") && (this.splitArray[j].scc !== "")
        
          && (this.splitArray[j].splitEndTime != ""))
         {
        this.attendanceData.push({
          "clockDate": this.attendanceData[0].clockDate,
          "clockTime": this.splitArray[j].splitStartTime,
          "clockTypeCode": "1",
          "jobFunctionCode": "",
          "lastChangeTs": this.attendanceData[0].lastChangeTs,
          "lastChangeUserid": this.attendanceData[0].lastChangeUserid,
          "opAreaCode": "",
          "shiftnbr": this.attendanceData[0].shiftnbr,
          "sccRowId":this.splitArray[j].sccRowId,
          "supplyChainCd": this.splitArray[j].scc,
          "taAssociateId": this.attendanceData[0].taAssociateId,
          "wrkAreacode": ""
        });
      }
    }
    var pay: any = { "attendance": [] } 
    pay = this.ShiftData;
    pay.facilityAreaCode = this.facilityId;
    console.log(this.attendanceData);
    let addDel=[];
     for(let t=0;t<this.attendanceData.length;t++)
      {
        if(this.delTimeArr.length>0)
        {
        for(let v=0;v<this.delTimeArr.length;v++)
        {
          if(this.attendanceData[t].sccRowId)
          {
          if(this.attendanceData[t].sccRowId==this.delTimeArr[v].sccRowId)
          { 
              this.attendanceData.splice(t,1); 
           }
          }
          
        }
        } 
      }
    pay.attendance =this.attendanceData;
    this.timesheetService.updateAttedance(pay)
      .subscribe((AssociateData) => {
        this.closeModal();
        this.showConfirmMsgModal = true ;
        this.confirmMsg = "Timesheet updated successfully" ;       
      },(err)=>{
         this.delTimeArr=[];
        this.showConfirmMsgModal = true ;
        this.confirmMsg = "Error while updating timesheet" ;
        console.error('failed to updateAttedance');
      });
         
  }

  closeConfirmMsgModal() {
    console.log('Close called');
    this.showConfirmMsgModal = false ;
    this.userUpdated.emit();
  }

  showModalBox(data: any){
    console.log('ShowModalBox hit');
    this.ShiftData = data;
    this.attendanceData = data.attendance;
    this.showModal = true;
    this.shiftDate = data.supplyChainCd;
    this.facilityId = data.facilityAreaCode;
    this.facilList=data.facilityTo
    if(this.attendanceData!==undefined && Array.isArray(this.attendanceData)==false)
    {
      var tempArr:any=[];
      tempArr.push(this.attendanceData);
      this.attendanceData=tempArr;
    }
    
    for(let tp=0;tp<this.attendanceData.length;tp++)
    {
      if(this.attendanceData[tp]['supplyChainCd'])
      {
      this.num++;
      var n = this.num.toString();
      this.attendanceData[tp]['sccRowId']=n;
      }
      
    }
  
    let attendanceStart = data.attendance.find(shiftData => {
      return shiftData.clockTypeCode == "1";
    });
    if(attendanceStart)
    {
      this.StartTime = attendanceStart.clockTime;
    }else{
      this.StartTime = "";
    }

    let attendanceEnd = data.attendance.find(shiftData => {
      return shiftData.clockTypeCode == "4";
    });
    if(attendanceEnd)
    {
      this.EndTime = attendanceEnd.clockTime;
    }else{
      this.EndTime="";
    }

    let attendanceBreakIn = data.attendance.find(shiftData => {
      return shiftData.clockTypeCode == "2";
    });
    if(attendanceBreakIn)
    {
      this.BreakInTime = attendanceBreakIn.clockTime !== undefined ? attendanceBreakIn.clockTime : "";//attendanceBreakIn.clockTime;
    }else{
      this.BreakInTime = '';
    }
    

    let attendanceBreakOut = data.attendance.find(shiftData => {
      return shiftData.clockTypeCode == "3";
    });
    if(attendanceBreakOut)
    {
      this.BreakOutTime = attendanceBreakOut.afterMealTime!==undefined? attendanceBreakOut.afterMealTime:"";
    }else{
       this.BreakOutTime="";
    }
    

     for (let h = 0; h < data.attendance.length; h++) {

       if(data.attendance[h]['supplyChainCd'])
       {
           this.splitArray.push({
        "scc": data.attendance[h].supplyChainCd,
        "splitStartTime": data.attendance[h].clockTime,    
       "sccPrevious": data.attendance[h].supplyChainCd,
       "sccRowId":data.attendance[h].sccRowId
      })
       } 
    }
    if(data.attendance.length>0 && this.splitArray.length==0)
         {
        this.splitArray.push({
        "scc": '',
        "splitStartTime":'',    
       "sccPrevious":'',
       "sccRowId":"1"
      })
         }
console.log('this.splitArray--->',this.splitArray);
  }

  shiftReset(){
    this.ShiftData.push({'this.shiftDate':""});
  }

  closeModal() {
    this.splitArray = [];
    this.showModal = false;
  }

  addTime() {
    if (this.splitArray.length > 0) {
      let empty = false;
      for (let jx = 0; jx < this.splitArray.length; jx++) {
        if ((this.splitArray[jx].scc == "") || (this.splitArray[jx].splitStartTime == "")) {
          empty = true;
        }
      }
      this.num++;
      var nt = this.num.toString();
      if (!empty) {
        
        this.splitArray.push({ "scc": "", "splitStartTime": "",  "sccPrevious": "","sccRowId":nt });
      }
    } else {
      this.splitArray.push({ "scc": "", "splitStartTime": "",  "sccPrevious": "","sccRowId":nt });
    }
   this.addTimeArr=this.splitArray;
    console.log(this.splitArray);
  }

  deleteTime(index) {
    console.log('index', index);
    this.num--;
    console.log(this.splitArray[index]);
    this.delTimeArr.push(this.splitArray[index]);
    console.log(this.delTimeArr);
    this.splitArray.splice(index, 1);
    
  }

}
