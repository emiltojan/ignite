
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { AddAssociateService } from './../../services/add-associate.service';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { ShiftSetupService } from './../../services/shift-setup.service';
import { Overlay } from 'ngx-modialog';
import { Modal } from 'ngx-modialog/plugins/bootstrap';

import {TranslateService} from '@ngx-translate/core';
import {MatMenuModule} from '@angular/material/menu';
import { Router } from '@angular/router';

import { MockBackend, MockConnection } from '@angular/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import {Http,HttpModule} from '@angular/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";

import { AppComponent } from '../../app.component';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { AddAssociateComponent } from './add-associate.component';
import { TimesheetService } from './../../services/timesheet.service';
import { AssignShiftService } from '../../services/assign-shift.service';
import { AppCommonServices } from './../../services/app-common.services';
import {GetExceptionsService} from './../../services/exception.service';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
export function HttpLoaderFactory(httpClient: HttpClient) {
 //return new TranslateHttpLoader(httpClient, "assets/i18n/", ".txt"); // Local
   return new TranslateHttpLoader(httpClient, "/tpr/assets/i18n/", ".txt"); // Production
}

describe('AddAssociateComponent', () => {
  let component: AddAssociateComponent;
  let fixture: ComponentFixture<AddAssociateComponent>;
  let modal;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAssociateComponent ],
       schemas: [NO_ERRORS_SCHEMA],
       imports:[ 
       BrowserModule,
       FormsModule,                              
       MatMenuModule,
       HttpModule,
       HttpClientModule, 
       HttpClientTestingModule, 
       TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
       }}),
      RouterTestingModule],
       providers:[TranslateService,AssignShiftService,{ provide: Modal, useValue: modal }]
    })
    .compileComponents();
    modal = { openModal: jasmine.createSpy('openModal') }
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAssociateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call showModalBox method ',function () {
    spyOn(component,'showModalBox');
    component.showModalBox(testData().value,testData().timesheet);
expect(component.showModalBox).toHaveBeenCalledWith(testData().value,testData().timesheet);
  });

//   it('should call addNewAssociate method ',function () {
//     spyOn(component,'addNewAssociate');
//     component.addNewAssociate(testData().newAssociate);
// expect(component.addNewAssociate).toHaveBeenCalledWith(testData().newAssociate);
//   });


 it('should call resetAddNewAssociateForm method ',function () {
    spyOn(component,'resetAddNewAssociateForm');
    component.resetAddNewAssociateForm();
expect(component.resetAddNewAssociateForm).toHaveBeenCalled();
  });

  it('should call resetAddNewAssociateForm method ',function () {
    spyOn(component,'resetAddNewAssociateForm');
    component.resetAddNewAssociateForm();
expect(component.resetAddNewAssociateForm).toHaveBeenCalled();
  });

});

function testData(){
    return { 
   value:true,
   timesheet:true,
   newAssociate :{
value :{
    obsoleteInd :'N',
    dfltSettingsEffDate :'02/20/2018',
    taAssociateId :'12345',
    shiftStartTime:'8:00',
    shiftDate :'02/20/2018',
    supplyChainCd :'123',
    dfltShiftNbr :2
}
   }
   }
}

// let modal;

// beforeEach(() => {
//   modal = { openModal: jasmine.createSpy('openModal') }

//   ...
//   providers: [
//     { provide: Modal, useValue: modal }
//   ]
// })

// it('', () => {
//   doSomething()

//   expect(modal.openModal).toHaveBeenCalledWith(whatever);
// })
