import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { FooterComponent } from './footer/footer.component';
import { SidebarComponent } from './sidebar/sidebar.component';
//import { TimeSheetEditOptionsComponent } from './time-sheet-edit-options/time-sheet-edit-options.component';
import { FilterByName, FilterById, FilterBySCC, FilterByOPs, FilterByJob, FilterByDfltShift, FilterByDfltFacility, FilterByOpsAreaDesc, FilterByAssocName, FilterByFacility  } from './filter/filter.component';


@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule
  ],
  declarations: [
    FooterComponent,
    SidebarComponent,
	//TimeSheetEditOptionsComponent,
    FilterByName, 
	FilterById, 
	FilterBySCC, 
  FilterByOPs, 
  FilterByJob, 
  FilterByDfltShift, 
  FilterByDfltFacility, 
  FilterByOpsAreaDesc,
  FilterByAssocName,
  FilterByFacility  
  ],
  exports: [
    FooterComponent,   
    SidebarComponent,
	//TimeSheetEditOptionsComponent,
    FilterByName, 
	FilterById, 
	FilterBySCC, 
  FilterByOPs, 
  FilterByJob, 
  FilterByDfltShift, 
  FilterByDfltFacility, 
  FilterByOpsAreaDesc, 
  FilterByAssocName,
  FilterByFacility  
  ]
})
export class ComponentsModule { }
