import { TestBed, async, inject } from '@angular/core/testing';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod,HttpModule} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule,HttpTestingController} from '@angular/common/http/testing';
import { ViewDetailsService } from './viewDetails.service';

describe('ViewDetailsService (Mocked)', () => {
  const mockResponse = {
      color: 'blue'
    };

  let subject: ViewDetailsService = null;
  let backend: MockBackend = null;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ViewDetailsService,

        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule,HttpClientModule,HttpClientTestingModule
      ]
    });
  });
 
  beforeEach(inject([ViewDetailsService, MockBackend], (viewDetail: ViewDetailsService, mockBackend: MockBackend) => {
    subject = viewDetail;
    backend = mockBackend;
  }));

  it('should construct viewDetail service', async(inject(
    [ViewDetailsService, MockBackend], (service, mockBackend) => {

    expect(service).toBeDefined();
  })));


    it('should call viewDetails service method', async(inject([ViewDetailsService, MockBackend], (dashBoard: ViewDetailsService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(testData().data) })));
      });

      subject
      .ViewDetails(testData().data)
      .then((response) => {
        expect(subject.ViewDetails(testData().data)).toBeTruthy();
      });
    })));


});


function testData() {

 return { 
 data :{
   supplyChainCd :'1234',
   shiftNbr : 2,
   prodDate : '02/20/2018'
 }
 };

}