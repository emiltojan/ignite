import { Injectable } from '@angular/core';
//import { Component } from '@angular/core';
import { Http } from '@angular/http';
import {HttpClient} from '@angular/common/http';
import 'rxjs/add/operator/toPromise';

@Injectable()
// @Component({
//     selector: 'app-timesheet',
//     templateUrl: './timesheet.component.html',
//     styleUrls: ['./timesheet.component.css']
// })
export class TimesheetService {
 result: any;
  
constructor(private http: Http,private httpC:HttpClient) { }
  
   AssociateDetails(date){
        //  return this.httpC.get('http://cn07484s4000d0b.s07484.cn.wal-mart.com:9887/tpr/cn/7484/attendance?attendanceDate='+ date)
         return this.httpC.get('http://10.117.170.249:8080/tpr-web/attendance?attendanceDate='+ date)
            //.toPromise()
            //.then(response => response.json())
           // .catch(this.handleError);
    }

    DeleteAssociateDetails(data){
        // return this.httpC.post('http://us32846s4000d0b.s32846.us:9887/tpr/us/7490/attendance/delete',data);
        return this.httpC.post('http://10.117.170.249:8080/tpr-web/attendance/delete',data);
    }

    updateAttedance(data: any){
        return this.httpC.put('http://10.117.170.249:8080/tpr-web/attendance', data)
    }
}
