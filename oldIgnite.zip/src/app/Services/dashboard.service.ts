import { Injectable } from '@angular/core';
//import { Component } from '@angular/core';
import { Http } from '@angular/http';
import {HttpClient} from '@angular/common/http';
import 'rxjs/add/operator/toPromise';

@Injectable()

export class DashboardService {
 result: any;
  
constructor(private http: Http,private httpC:HttpClient) { }
  
   overAllPerformance(date,shift){
        //return this.httpC.get('http://us32846s4000d0b.s32846.us.wal-mart.com:9887/tpr/us/7490/dashboard/overall/performance?shiftNbr='+shift+'&prefDate='+date);
        // return this.httpC.get('http://10.117.170.249:8080/tpr-web/dashboard/overall/performance?shiftNbr='+shift+'&perfDate='+date);
         return this.httpC.get('http://10.117.170.249:8080/tpr-web/dashboard/overall/performance?searchDate='+date+'&shiftNbr='+shift);
         
   }

    myTeamPerformance(date,shift){
         //return this.httpC.get('http://us32846s4000d0b.s32846.us.wal-mart.com:9887/tpr/us/7490/dashboard/myteam/performance?shiftNbr='+shift+'&prefDate='+date);
        //return this.httpC.get('http://10.117.170.249:8080/tpr-web/dashboard/myteam/performance?shiftNbr='+shift+'&perfDate='+date);
         return this.httpC.get('http://10.117.170.249:8080/tpr-web/dashboard/myteam/performance?searchDate='+date+'&shiftNbr='+shift);
    }


GetSupervisor(data : any) : Promise<any> {
    return this.http.get('http://10.117.170.249:8080/tpr-web/setup/isSupervisor',data)
            .toPromise()
            .then(response => response.json())
}   
}
