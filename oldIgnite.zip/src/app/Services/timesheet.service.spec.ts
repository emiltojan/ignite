import { TestBed, async, inject } from '@angular/core/testing';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod,HttpModule} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule,HttpTestingController} from '@angular/common/http/testing';
import 'rxjs/add/operator/toPromise';
import { AppCommonServices } from './app-common.services';
import { TimesheetService } from './timesheet.service';

describe('TimesheetService (Mocked)', () => {
  const mockResponse = {
      color: 'blue'
    };

  let subject: TimesheetService = null;
  let backend: MockBackend = null;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        TimesheetService,
        AppCommonServices,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule,HttpClientModule,HttpClientTestingModule
      ]
    });
  });
 
  beforeEach(inject([TimesheetService, MockBackend], (getException: TimesheetService, mockBackend: MockBackend) => {
    subject = getException;
    backend = mockBackend;
  }));

  it('should construct TimesheetService service', async(inject(
    [TimesheetService, MockBackend], (service, mockBackend) => {

    expect(service).toBeDefined();
  })));



    it('should call AssociateDetails service method', async(inject([TimesheetService, MockBackend], (dashBoard: TimesheetService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify('') })));
      });

      subject
      .AssociateDetails('2018/02/19')
      .subscribe((response) => {
        expect(subject.AssociateDetails('2018/02/19')).toEqual({success:true});
      });
    })));

    it('should call updateAttedance service method', async(inject([TimesheetService, MockBackend], (dashBoard: TimesheetService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify('') })));
      });

      subject
      .updateAttedance(updateAttedance)
      .subscribe((response) => {
        expect(subject.AssociateDetails(updateAttedance)).toEqual({success:true});
      });
    })));
    
     it('should call DeleteAssociateDetails service method', async(inject([TimesheetService, MockBackend], (dashBoard: TimesheetService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify('') })));
      });

      subject
      .DeleteAssociateDetails(SCData())
      .subscribe((response) => {
        expect(subject.DeleteAssociateDetails(SCData())).toEqual({success:true});
      });
    })));


});

function SCData(){
  return {"associateDetails":[{"attendClockDate":"2018/2/19","taAssociateId":"530742"}]}
}

var updateAttedance=[
  {
    "taAssociateId": "1174840002",
    "clockTime": "8:00",
    "shiftnbr": "1",
    "clockDate": "2018-2-19",
    "supplyChainCd": "111111111"
  },
  {
    "taAssociateId": "1174840002",
    "clockTime": "8:00",
    "shiftnbr": "1",
    "clockDate": "2018-2-19",
    "supplyChainCd": "001001002"
  },
  {
    "taAssociateId": "1174840002",
    "clockTime": "11:00",
    "shiftnbr": "1",
    "clockDate": "2018-2-19",
    "supplyChainCd": "666666666"
  },
  {
    "taAssociateId": "1174840002",
    "clockTime": "13:00",
    "shiftnbr": "1",
    "clockDate": "2018-2-19",
    "supplyChainCd": "002001007"
  },
  {
    "taAssociateId": "1174840002",
    "clockTime": "4:00",
    "shiftnbr": "1",
    "clockDate": "2018-2-19",
    "supplyChainCd": "999999999"
  },
  {
    "taAssociateId": "1174840020",
    "clockTime": "8:00",
    "shiftnbr": "1",
    "clockDate": "2018-2-19",
    "supplyChainCd": "111111111"
  },
  {
    "taAssociateId": "1174840020",
    "clockTime": "8:00",
    "shiftnbr": "1",
    "clockDate": "2018-2-19",
    "supplyChainCd": "001001002"
  },
  {
    "taAssociateId": "1174840020",
    "clockTime": "11:00",
    "shiftnbr": "1",
    "clockDate": "2018-2-19",
    "supplyChainCd": "666666666"
  },
  {
    "taAssociateId": "1174840020",
    "clockTime": "13:00",
    "shiftnbr": "1",
    "clockDate": "2018-2-19",
    "supplyChainCd": "002001007"
  },
  {
    "taAssociateId": "1174840020",
    "clockTime": "4:00",
    "shiftnbr": "1",
    "clockDate": "2018-2-19",
    "supplyChainCd": "999999999"
  }
]

