import { TestBed, inject } from '@angular/core/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import { LoginService } from './login.service';

describe('LoginService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientModule,HttpClientTestingModule],
      providers: [LoginService]
    });
  });

  it('should be created', inject([HttpClientModule,HttpClientTestingModule], (service: LoginService) => {
    expect(service).toBeTruthy();
  }));
});
