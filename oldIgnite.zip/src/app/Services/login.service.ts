import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class LoginService {
 result: any;
  
constructor(private http: Http) { }
getUserDetails:any={
      userName:String,
      userLang:String
  };
  
   Authentication(data: any): Promise<any> {
        // return this.http.put('http://nimservices.s0'+data.businessUnitId+'.'+data.domainName+'.wal-mart.com:7099/securityMgmt/'+data.domainName+'/0'+data.businessUnitId+'/users/authenticate', data)
        //  return this.http.put('http://nimservices.s07466.mx.wal-mart.com:7099/securityMgmt/mx/07466/users/authenticate',data)
         return this.http.put('http://nimservices.s32846.us.wal-mart.com:7099/securityMgmt/us/32846/users/authenticate',data)
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
    }

CapabilityValidation(options) : Promise<any> {
    return this.http.get('http://nimservices.s32846.us.wal-mart.com:7099/securityMgmt/us/32846/users/1/capabilities',options)
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
}

GetSupervisor(data : any) : Promise<any> {
    return this.http.get('http://10.117.170.249:8080/tpr-web/setup/isSupervisor',data)
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
}




    private authorizeUser(response: any): Promise<any> {
        var adGroups;
        var result = [];
console.log(response);
       // adGroups = response.json().adGroups.split(",");
         result =response.json();
        // for (var i = 0; i < adGroups.length; i++) {
        //     console.log(adGroups[i].toString().trim());
        //     if (adGroups[i].toString().trim() === 'GLS Project') {
        //         console.log("AUTHORIZED!!!");
        //         result =response.json();
        //         break;
        //     } else {
        //         console.log("UNAUTHORIZED!!!");
        //     }
        // }

        return Promise.resolve(result || {});
    }

        private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); 
        return Promise.reject(error.message || error);
    }
}
