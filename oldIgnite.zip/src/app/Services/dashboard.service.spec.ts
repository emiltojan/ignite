import { TestBed, async, inject } from '@angular/core/testing';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod,HttpModule} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule,HttpTestingController} from '@angular/common/http/testing';
import { DashboardService } from './dashboard.service';
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
export function HttpLoaderFactory(httpClient: HttpClient) {
 //return new TranslateHttpLoader(httpClient, "assets/i18n/", ".txt"); // Local
   return new TranslateHttpLoader(httpClient, "/tpr/assets/i18n/", ".txt"); // Production
}
describe('DashboardService (Mocked)', () => {
  const mockResponse = {
      color: 'blue'
    };

  let subject: DashboardService = null;
  let backend: MockBackend = null;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        DashboardService,

        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule,HttpClientModule,HttpClientTestingModule,
         TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
       }}),
      ]
    });
  });
 
  beforeEach(inject([DashboardService, MockBackend], (dashBoard: DashboardService, mockBackend: MockBackend) => {
    subject = dashBoard;
    backend = mockBackend;
  }));

  it('should construct dashboard service', async(inject(
    [DashboardService, MockBackend], (service, mockBackend) => {

    expect(service).toBeDefined();
  })));


    it('should call overAllPerformance', async(inject([DashboardService, MockBackend], (dashBoard: DashboardService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(testData()) })));
      });

      subject
      .overAllPerformance(testData().date,testData().shiftNum)
      .subscribe((response) => {
        expect(subject.overAllPerformance(testData().date,testData().shiftNum)).toEqual({ success: true });
      });
    })));


    it('should call myTeam Performance', async(inject([DashboardService, MockBackend], (dashBoard: DashboardService, mockBackend: MockBackend) => {
   
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(testData()) })));
      });

      subject
      .myTeamPerformance(testData().date,testData().shiftNum)
      .subscribe((response) => {
        expect(subject.myTeamPerformance(testData().date,testData().shiftNum)).toEqual({ success: true });
      });
    })));

});


function testData() {

 return { 
 date :'02/10/2018',
 shiftNum :2
 };

}