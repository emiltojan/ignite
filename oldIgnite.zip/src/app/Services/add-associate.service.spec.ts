
import { TestBed, async, inject } from '@angular/core/testing';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod,HttpModule} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule,HttpTestingController} from '@angular/common/http/testing';
import { AddAssociateService } from './add-associate.service';

describe('AddAssociateService (Mocked)', () => {
  const mockResponse = {
      color: 'blue'
    };

  let subject: AddAssociateService = null;
  let backend: MockBackend = null;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AddAssociateService,

        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule,HttpClientModule,HttpClientTestingModule
      ]
    });
  });
 
  beforeEach(inject([AddAssociateService, MockBackend], (viewDetail: AddAssociateService, mockBackend: MockBackend) => {
    subject = viewDetail;
    backend = mockBackend;
  }));

  it('should construct viewDetail service', async(inject(
    [AddAssociateService, MockBackend], (service, mockBackend) => {

    expect(service).toBeDefined();
  })));


    it('should call addAssociates service method', async(inject([AddAssociateService, MockBackend], (dashBoard: AddAssociateService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(testData().data) })));
      });

      subject
      .addAssociate(testData().data)
      .subscribe((response) => {
        expect(subject.addAssociate(testData().data)).toEqual({success:true});
      });
    })));

    // validateSCC
it('should call validate SCC service called', async(inject([AddAssociateService, MockBackend], (dashBoard: AddAssociateService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(testData().data) })));
      });
      var scc='001001002'
      subject
      .validateSCC(scc)
      .subscribe((response) => {
        expect(subject.validateSCC(scc)).toEqual({success:true});//not.toEqual(null);
      });
    })));

    it('should call addTimeAttendance service called', async(inject([AddAssociateService, MockBackend], (dashBoard: AddAssociateService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(testData().data) })));
      });
      var scc={};
      subject
      .addTimeAttendance(scc)
      .subscribe((response) => {
        expect(subject.addTimeAttendance(scc)).toEqual({success:true});
      });
    })));

});


function testData() {

 return { 
 data :{
   supplyChainCd :'1234',
   shiftNbr : 2,
   prodDate : '02/20/2018'
 }
 };

}

