import { TestBed, async, inject } from '@angular/core/testing';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod,HttpModule} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule,HttpTestingController} from '@angular/common/http/testing';
import { LoginService } from './login.service';

describe('LoginService (Mocked)', () => {
  const mockResponse = {
      color: 'blue'
    };

  let subject: LoginService = null;
  let backend: MockBackend = null;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        LoginService,

        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule,HttpClientModule,HttpClientTestingModule
      ]
    });
  });
 
  beforeEach(inject([LoginService, MockBackend], (loginService: LoginService, mockBackend: MockBackend) => {
    subject = loginService;
    backend = mockBackend;
  }));

  it('should construct loginService service', async(inject(
    [LoginService, MockBackend], (service, mockBackend) => {

    expect(service).toBeDefined();
  })));


    // it('should call Authentication service method', async(inject([LoginService, MockBackend], (dashBoard: LoginService, mockBackend: MockBackend) => {
 
    //   mockBackend.connections.subscribe(conn => {
    //     conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(testData()) })));
    //   });

    //   subject
    //   .Authentication(testData())
    //   .then((response) => {
    //     expect(subject.Authentication(testData())).toBeTruthy();
    //   });
    // })));



   
});


function testData() {

 return { 
 data :{
   supplyChainCd :'1234',
   shiftNbr : 2,
   prodDate : '02/20/2018'
 }
 };

}


