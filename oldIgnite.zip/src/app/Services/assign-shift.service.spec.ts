import { TestBed, async, inject } from '@angular/core/testing';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod,HttpModule} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule,HttpTestingController} from '@angular/common/http/testing';
import { AssignShiftService } from './assign-shift.service';

describe('AssignShiftService (Mocked)', () => {
  const mockResponse = {
      color: 'blue'
    };

  let subject: AssignShiftService = null;
  let backend: MockBackend = null;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AssignShiftService,

        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule,HttpClientModule,HttpClientTestingModule
      ]
    });
  });
 
  beforeEach(inject([AssignShiftService, MockBackend], (viewDetail: AssignShiftService, mockBackend: MockBackend) => {
    subject = viewDetail;
    backend = mockBackend;
  }));

  it('should construct viewDetail service', async(inject(
    [AssignShiftService, MockBackend], (service, mockBackend) => {

    expect(service).toBeDefined();
  })));


    it('should call assignShift service method', async(inject([AssignShiftService, MockBackend], (dashBoard: AssignShiftService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(data) })));
      });
      var data={};
      subject
      .assignShift(data)
      .subscribe((response) => {
        expect(subject.assignShift(data)).toEqual({success:true});
      });
    })));

    // validateSCC
it('should call getShiftsList service called', async(inject([AssignShiftService, MockBackend], (dashBoard: AssignShiftService, mockBackend: MockBackend) => {
 
      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(scc) })));
      });
      var scc='001001002'
      subject
      .getShiftsList()
      .subscribe((response) => {
        expect(subject.getShiftsList()).not.toEqual(null);
      });
    })));

   

});




