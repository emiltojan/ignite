import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';

import { TimesheetComponent } from './pages/timesheet/timesheet.component';
import { TprsetupComponent } from './pages/tprsetup/tprsetup.component';
import { SupplyChainComponent } from './pages/supplyChain/supplychain.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ProductivityComponent } from './pages/productivity/productivity.component';
import { LoginComponent } from './pages/login/login.component';
import { ViewDetailsComponent } from './pages/view-details/view-details.component';


const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'ledgerreview', component: TprsetupComponent },
  { path: 'timesheet', component: TimesheetComponent },
  { path: 'productivity', component: ProductivityComponent },
  { path: 'supplychain', component: SupplyChainComponent },
  { path: 'login', component: LoginComponent },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'view-details', component: ViewDetailsComponent,data:{} }
];

export const AppRoutingModule = RouterModule.forRoot(routes, { useHash: true });
