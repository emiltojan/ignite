# team-productivity-client
Repository to manage the Team Productivity Application - UI component

# Using this Project
You'll need the @angular CLI with support for v2 apps:

$ npm install -g @angular/cli
Notes: If angular does not seem to install globally due to permissions, you can install locally and execute it with it's path.

$ npm install @angular/cli
$ node_modules/angular/bin/ng serve
Then, cd into the team-productivity-client directory if not already there

$ cd team-productivity-client
and Install the project dependencies

$ npm install
Then serve the project:

$ ng serve

To run the unit tests

$ npm test
